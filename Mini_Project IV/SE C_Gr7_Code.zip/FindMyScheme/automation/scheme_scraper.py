import mysql.connector
from datetime import datetime
import logging
import time

# Selenium Imports
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# ==========================================
# 1. Configuration & Setup
# ==========================================

# Database Configuration
DB_HOST = "localhost"
DB_USER = "root"      # Change if your MySQL user is different
DB_PASS = ""          # Change if your MySQL password is set
DB_NAME = "findmyscheme"

# Target URLs (For college project, these are structural examples)
# Note: myscheme.gov.in is highly dynamic. You might need Selenium for exact extraction.
# Here we use a standard BeautifulSoup approach.
URLS_TO_SCRAPE = [
    "https://www.myscheme.gov.in/" # Replace with actual target URL or Mock URL
]

# Set up basic logging (Print to console)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

# ==========================================
# 2. Database Connection & Setup DB Tables
# ==========================================

def get_db_connection():
    """Establish connection to MySQL Database"""
    try:
        conn = mysql.connector.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASS,
            database=DB_NAME
        )
        return conn
    except mysql.connector.Error as err:
        logging.error(f"Error connecting to MySQL: {err}")
        return None

def setup_logs_table(cursor):
    """Create agent_logs table if it does not exist"""
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS agent_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            run_time DATETIME,
            schemes_added INT,
            schemes_updated INT,
            errors_count INT,
            error_details TEXT
        )
    """)

# ==========================================
# 3. Heuristic Rule Extractor
# ==========================================

def extract_eligibility_rules(text):
    """
    Since the scraper only grabs basic summary text, we use this smart keyword
    analyzer to guess the actual database eligibility rules (age, income, caste).
    """
    text = text.lower()
    rules = {
        "age_min": None,
        "age_max": None,
        "income_max": None,
        "caste_category": None
    }
    
    # 1. Income Logic
    if any(word in text for word in ["poor", "bpl", "below poverty line", "economically weaker", "bpl families", "garib"]):
        rules["income_max"] = 250000
    elif any(word in text for word in ["middle class", "low income"]):
        rules["income_max"] = 500000
    
    # 2. Age Logic
    if any(word in text for word in ["student", "child", "youth", "education", "scholarship", "school", "graduate"]):
        rules["age_min"] = 5
        rules["age_max"] = 30
    elif any(word in text for word in ["senior citizen", "elderly", "old age", "pension"]):
        rules["age_min"] = 60
        rules["age_max"] = 120
    
    # 3. Caste Logic
    if " obc" in text or "other backward class" in text:
        rules["caste_category"] = "OBC"
    elif " sc" in text or " st" in text or "sc/st" in text or "dalit" in text or "scheduled caste" in text:
        rules["caste_category"] = "SC/ST"
    elif "minority" in text or "minorities" in text:
        rules["caste_category"] = "Minority"
        
    return rules

# ==========================================
# 4. Scraping Logic
# ==========================================

def scrape_schemes():
    """Scrape schemes from the website using Selenium (Browser Automation)."""
    scraped_data = []
    
    # Setup Chrome Options
    chrome_options = Options()
    # Uncomment the next line to run Chrome "headless" (invisible background)
    # chrome_options.add_argument("--headless")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--window-size=1920,1080")
    
    logging.info("Launching Chrome Browser for scraping...")
    
    try:
        # Selenium 4 has a built-in Selenium Manager to handle ChromeDriver automatically.
        driver = webdriver.Chrome(options=chrome_options)
        
        url = URLS_TO_SCRAPE[0]
        # Typically the search page has the list
        if "search" not in url:
            url = "https://www.myscheme.gov.in/search"
            
        logging.info(f"Navigating to {url}")
        driver.get(url)
        
        # We will loop through 5 pages automatically (approx 50 schemes) to demonstrate scale
        # safely without triggering government bot-protections or IP bans.
        MAX_PAGES = 5
        current_page = 1
        
        while current_page <= MAX_PAGES:
            logging.info(f"--- Scraping Page {current_page} of {MAX_PAGES} ---")
            logging.info("Waiting for data to load on the page...")
            time.sleep(10) # Simple sleep to allow full React render
            
            # Find all card elements on the current page
            cards = driver.find_elements(By.CSS_SELECTOR, "div.bg-white, div.card, a[href*='/schemes/']")
            
            for card in cards:
                # We removed the hardcoded limit of 10. It will now extract ALL schemes currently loaded on the screen.
                # NOTE: Government websites use heavy pagination (multiple pages). Only what is rendered visually will be picked up.
                    
                try:
                    # Try to extract details within the card
                    text_content = card.text.strip()
                    if not text_content or len(text_content) < 20:
                        continue
                    
                    # Assume the first line is the scheme name
                    lines = text_content.split('\n')
                    name = lines[0]
                    
                    # Mock extracting other fields based on generic layout
                    desc = lines[1] if len(lines) > 1 else "Description not extracted"
                    
                    # 💡 Smart Heuristic: Extract real values by analyzing the description/title words!
                    inferred_rules = extract_eligibility_rules(name + " " + desc)
                    
                    scheme_data = {
                        "name": name[:200], # max length
                        "description": desc,
                        "benefits": "Extracted via Selenium from myscheme",
                        "eligibility": "Refer to official portal for detailed eligibility rules.",
                        "official_link": "https://www.myscheme.gov.in",
                        "age_min": inferred_rules["age_min"],
                        "age_max": inferred_rules["age_max"],
                        "income_max": inferred_rules["income_max"],
                        "caste_category": inferred_rules["caste_category"]
                    }
                    
                    # Basic duplicate prevention in our list
                    if not any(s['name'] == scheme_data['name'] for s in scraped_data):
                        scraped_data.append(scheme_data)
                except Exception as e:
                    pass
            
            # Try to navigate to the Next Page
            if current_page < MAX_PAGES:
                try:
                    # Look for the "Next" button using common pagination keywords/arrows
                    # Includes checking for buttons or anchor tags containing Next, >, or specific aria-labels
                    next_button = driver.find_element(
                        By.XPATH, 
                        "//button[contains(translate(., 'NEXT', 'next'), 'next') or contains(@aria-label, 'Next')] | //a[contains(translate(., 'NEXT', 'next'), 'next') or contains(@aria-label, 'Next')]"
                    )
                    
                    # Scroll to it just to be safe
                    driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", next_button)
                    time.sleep(2)
                    
                    # Click it
                    next_button.click()
                    logging.info(f"Clicked 'Next'. Moving to page {current_page + 1}...")
                except Exception as e:
                    logging.info("Reached end of pagination or could not find 'Next' button. Scraping loop finished.")
                    break # No more pages
            
            current_page += 1
            
        logging.info(f"Selenium successfully extracted {len(scraped_data)} total schemes across the pages.")
        
    except Exception as e:
        logging.error(f"Critical Selenium Scraping Error: {e}")
    finally:
        try:
            driver.quit() # Always close the browser
        except:
            pass
            
    return scraped_data

# ==========================================
# 5. Data Insertion & Updating
# ==========================================

def sync_schemes_to_db(schemes, conn):
    """Insert or update schemes in the database, and return stats."""
    cursor = conn.cursor()
    
    stats = {
        "added": 0,
        "updated": 0,
        "deactivated": 0,
        "errors": 0,
        "error_list": []
    }
    
    # Keep track of all names we scraped today
    scraped_names = [s['name'] for s in schemes]
    
    for scheme in schemes:
        try:
            # Check if scheme already exists
            check_sql = "SELECT id, description FROM schemes WHERE name = %s"
            cursor.execute(check_sql, (scheme['name'],))
            result = cursor.fetchone()
            
            # Note: Putting 'eligibility' inside 'application_process' as per db schema
            if result:
                # Scheme exists - force update to ensure new heuristic rules are ALWAYS applied!
                update_sql = """
                    UPDATE schemes 
                    SET description=%s, benefits=%s, apply_url=%s, application_process=%s, updated_at=NOW()
                    WHERE name=%s
                """
                cursor.execute(update_sql, (
                    scheme['description'], scheme['benefits'], 
                    scheme['official_link'], scheme['eligibility'], scheme['name']
                ))
                
                # Update eligibility rule mapping
                update_eligibility_sql = """
                    UPDATE eligibility_rules 
                    SET age_min=%s, age_max=%s, income_max=%s, caste_category=%s, other_criteria=%s
                    WHERE scheme_id=%s
                """
                cursor.execute(update_eligibility_sql, (
                    scheme.get('age_min'), 
                    scheme.get('age_max'), 
                    scheme.get('income_max'), 
                    scheme.get('caste_category'), 
                    scheme['eligibility'],
                    result[0] # scheme_id
                ))
                
                conn.commit()
                stats["updated"] += 1
            else:
                # Scheme does not exist - Insert new
                insert_sql = """
                    INSERT INTO schemes (name, description, benefits, apply_url, application_process, status, created_at)
                    VALUES (%s, %s, %s, %s, %s, 'active', NOW())
                """
                cursor.execute(insert_sql, (
                    scheme['name'], scheme['description'], scheme['benefits'],
                    scheme['official_link'], scheme['eligibility']
                ))
                scheme_id = cursor.lastrowid
                
                # Insert mapped eligibility rule
                eligibility_sql = """
                    INSERT INTO eligibility_rules (scheme_id, age_min, age_max, income_max, caste_category, other_criteria)
                    VALUES (%s, %s, %s, %s, %s, %s)
                """
                cursor.execute(eligibility_sql, (
                    scheme_id, 
                    scheme.get('age_min'), 
                    scheme.get('age_max'), 
                    scheme.get('income_max'), 
                    scheme.get('caste_category'), 
                    scheme['eligibility']
                ))
                
                
                conn.commit()
                stats["added"] += 1
                
        except Exception as e:
            stats["errors"] += 1
            stats["error_list"].append(str(e))
            logging.error(f"Error processing scheme '{scheme['name']}': {e}")
            
    # ----------------------------------------------------
    # EXPIRED SCHEME MANAGEMENT (Deactivate missing schemes)
    # ----------------------------------------------------
    if scraped_names:
        try:
            # Setting status='inactive' instead of hard DELETING. 
            # Deleting would destroy all users' historical applications/search history (due to CASCADE).
            format_strings = ','.join(['%s'] * len(scraped_names))
            deactivate_sql = f"UPDATE schemes SET status='inactive' WHERE name NOT IN ({format_strings}) AND status='active'"
            
            cursor.execute(deactivate_sql, tuple(scraped_names))
            stats["deactivated"] = cursor.rowcount
            conn.commit()
            if stats["deactivated"] > 0:
                logging.info(f"Deactivated {stats['deactivated']} expired schemes.")
                
        except Exception as e:
            logging.error(f"Error managing expired schemes: {e}")
            
    cursor.close()
    return stats

# ==========================================
# 6. Logging to DB
# ==========================================

def log_run_stats(conn, stats):
    """Save the execution results into agent_logs table."""
    cursor = conn.cursor()
    try:
        setup_logs_table(cursor)
        
        insert_log = """
            INSERT INTO agent_logs (run_time, schemes_added, schemes_updated, errors_count, error_details)
            VALUES (NOW(), %s, %s, %s, %s)
        """
        err_details = " | ".join(stats["error_list"]) if stats["errors"] > 0 else "None"
        cursor.execute(insert_log, (stats["added"], stats["updated"] + stats["deactivated"], stats["errors"], err_details))
        conn.commit()
        logging.info("Run stats successfully logged to agent_logs table.")
        
    except Exception as e:
        logging.error(f"Failed to save logs to DB: {e}")
    finally:
        cursor.close()

# ==========================================
# 7. Main Execution
# ==========================================

if __name__ == "__main__":
    logging.info("Starting Scheme Scraping Automation...")
    
    # 1. Connect to DB
    conn = get_db_connection()
    
    if conn:
        # 2. Scrape Data
        logging.info("Scraping websites for new scheme data...")
        extracted_schemes = scrape_schemes()
        
        # 3. Process and Sync to DB
        logging.info(f"Retrieved {len(extracted_schemes)} schemes. Syncing to database...")
        run_stats = sync_schemes_to_db(extracted_schemes, conn)
        
        # 4. Log results
        logging.info(f"Sync Complete. Added: {run_stats['added']}, Updated: {run_stats['updated']}, Deactivated: {run_stats['deactivated']}, Errors: {run_stats['errors']}")
        log_run_stats(conn, run_stats)
        
        # Close connection
        conn.close()
        logging.info("Database connection closed. Automation finished.")
    else:
        logging.error("Automation aborted due to DB connection failure.")
