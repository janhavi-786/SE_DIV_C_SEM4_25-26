<?php
// About Page (session-aware)
session_start();
require_once __DIR__ . '/includes/auth.php';

$loggedIn = isLoggedIn();
$user = $loggedIn ? getCurrentUser() : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <!-- Header/Navigation -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="about.php">About</a>
                    <div class="nav-auth">
                        <?php if ($loggedIn): ?>
                            <a href="dashboard.php" class="btn btn-primary btn-small">Dashboard</a>
                            <a href="php/logout.php" class="btn btn-outline btn-small">Logout</a>
                        <?php else: ?>
                            <a href="login.php" class="btn btn-primary btn-small">Login</a>
                            <a href="register.php" class="btn btn-outline btn-small">Register</a>
                        <?php endif; ?>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero Section for About -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>About FindMyScheme</h1>
                <p>Empowering Citizens to Access Government Benefits Easily and Securely</p>
            </div>
        </div>
    </section>

    <!-- About Content Section -->
    <section class="container" style="padding: 60px 15px;">
        <div class="row">
            <div class="col-half">
                <h2>Our Mission</h2>
                <p>FindMyScheme is a government-backed initiative dedicated to making it easier for citizens to discover and access government schemes they're eligible for.</p>
                <p>We understand that there are hundreds of government schemes available, but most citizens don't know which ones they qualify for. Our mission is to bridge this critical gap and ensure every citizen can access the benefits they deserve.</p>
                <p style="color: #1a237e; font-weight: 600; margin-top: 20px;">Core Values:</p>
                <ul style="list-style: none; padding: 0;">
                    <li style="margin: 10px 0; color: #333;"><span style="color: #2e7d32; font-weight: 700;">✓</span> Transparency in all operations</li>
                    <li style="margin: 10px 0; color: #333;"><span style="color: #2e7d32; font-weight: 700;">✓</span> User-first approach</li>
                    <li style="margin: 10px 0; color: #333;"><span style="color: #2e7d32; font-weight: 700;">✓</span> Data privacy & security</li>
                    <li style="margin: 10px 0; color: #333;"><span style="color: #2e7d32; font-weight: 700;">✓</span> Continuous improvement</li>
                </ul>
            </div>
            <div class="col-half" style="display: flex; align-items: center; justify-content: center;">
                <div style="text-align: center;">
                    <div style="font-size: 5rem; margin-bottom: 20px;">🏛️</div>
                    <p style="color: #666; font-size: 16px; font-weight: 600;">Making Government Services Accessible to All Citizens</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistics Section -->
    <section style="background-color: #f0f4ff; padding: 60px 15px; margin: 40px 0;">
        <div class="container">
            <h2 style="text-align: center; margin-bottom: 50px;">Our Impact</h2>
            <div class="row">
                <div class="col-third">
                    <div class="card" style="text-align: center; padding: 30px;">
                        <div style="font-size: 3rem; color: #1a237e; font-weight: 700; margin-bottom: 10px;">500+</div>
                        <h3 style="color: #1a237e; font-size: 18px;">Active Schemes</h3>
                        <p style="color: #666;">Regular updates with latest government schemes</p>
                    </div>
                </div>
                <div class="col-third">
                    <div class="card" style="text-align: center; padding: 30px;">
                        <div style="font-size: 3rem; color: #ff9800; font-weight: 700; margin-bottom: 10px;">50K+</div>
                        <h3 style="color: #1a237e; font-size: 18px;">Happy Users</h3>
                        <p style="color: #666;">Citizens accessing schemes successfully</p>
                    </div>
                </div>
                <div class="col-third">
                    <div class="card" style="text-align: center; padding: 30px;">
                        <div style="font-size: 3rem; color: #2e7d32; font-weight: 700; margin-bottom: 10px;">24/7</div>
                        <h3 style="color: #1a237e; font-size: 18px;">AI Support</h3>
                        <p style="color: #666;">Always available chatbot assistance</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Key Features Section -->
    <section id="features" class="container" style="padding: 60px 15px;">
        <h2 style="text-align: center; margin-bottom: 50px;">Why Choose FindMyScheme?</h2>
        <div class="row">
            <div class="col-half">
                <div class="card" style="margin-bottom: 25px; padding: 25px;">
                    <div style="font-size: 2.5rem; margin-bottom: 15px;">🔐</div>
                    <h3 style="color: #1a237e; margin-top: 0;">Secure & Private</h3>
                    <p>Your personal data is encrypted with military-grade security. We follow all RBI and government privacy guidelines to protect your information.</p>
                </div>
            </div>
            <div class="col-half">
                <div class="card" style="margin-bottom: 25px; padding: 25px;">
                    <div style="font-size: 2.5rem; margin-bottom: 15px;">📱</div>
                    <h3 style="color: #1a237e; margin-top: 0;">Mobile Friendly</h3>
                    <p>Access from any device, anywhere, anytime. No installation required. Fully responsive design works perfectly on phones, tablets, and desktops.</p>
                </div>
            </div>
            <div class="col-half">
                <div class="card" style="margin-bottom: 25px; padding: 25px;">
                    <div style="font-size: 2.5rem; margin-bottom: 15px;">🤖</div>
                    <h3 style="color: #1a237e; margin-top: 0;">AI Chatbot Support</h3>
                    <p>24/7 intelligent chatbot assistant to answer your questions instantly. Get real-time guidance on schemes, eligibility, and application processes.</p>
                </div>
            </div>
            <div class="col-half">
                <div class="card" style="margin-bottom: 25px; padding: 25px;">
                    <div style="font-size: 2.5rem; margin-bottom: 15px;">✨</div>
                    <h3 style="color: #1a237e; margin-top: 0;">Simple & Clear</h3>
                    <p>No complex jargon or technical terms. Everything explained in simple, everyday language that anyone can understand and follow.</p>
                </div>
            </div>
            <div class="col-half">
                <div class="card" style="margin-bottom: 25px; padding: 25px;">
                    <div style="font-size: 2.5rem; margin-bottom: 15px;">⚡</div>
                    <h3 style="color: #1a237e; margin-top: 0;">Lightning Fast</h3>
                    <p>Optimized for speed. Get your scheme results instantly with our advanced matching algorithm that considers multiple eligibility criteria.</p>
                </div>
            </div>
            <div class="col-half">
                <div class="card" style="margin-bottom: 25px; padding: 25px;">
                    <div style="font-size: 2.5rem; margin-bottom: 15px;">📊</div>
                    <h3 style="color: #1a237e; margin-top: 0;">Updated Database</h3>
                    <p>Always up-to-date with the latest government schemes from central and state governments. New schemes added regularly.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section style="background-color: #f0f4ff; padding: 60px 15px;">
        <div class="container">
            <h2 style="text-align: center; margin-bottom: 50px;">How It Works</h2>
            <div class="row">
                <div class="col-third">
                    <div class="card" style="text-align: center; padding: 25px;">
                        <div style="font-size: 2rem; margin-bottom: 15px;">📝</div>
                        <h3 style="color: #1a237e;">1. Create Account</h3>
                        <p>Register with your basic information. Simple, fast, and secure registration process.</p>
                    </div>
                </div>
                <div class="col-third">
                    <div class="card" style="text-align: center; padding: 25px;">
                        <div style="font-size: 2rem; margin-bottom: 15px;">🎯</div>
                        <h3 style="color: #1a237e;">2. Fill Your Details</h3>
                        <p>Provide your profile information like age, income, occupation, and state. Takes just 2 minutes.</p>
                    </div>
                </div>
                <div class="col-third">
                    <div class="card" style="text-align: center; padding: 25px;">
                        <div style="font-size: 2rem; margin-bottom: 15px;">✅</div>
                        <h3 style="color: #1a237e;">3. Get Results</h3>
                        <p>See all schemes you're eligible for with detailed explanations and eligibility criteria.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="container" style="padding: 60px 15px;">
        <h2 style="text-align: center; margin-bottom: 50px;">What Users Say</h2>
        <div class="row">
            <div class="col-third">
                <div class="card" style="padding: 25px;">
                    <p style="margin-top: 0;">"FindMyScheme helped me discover 5 schemes I was eligible for. The interface is so easy to use!"</p>
                    <p style="color: #1a237e; font-weight: 600; margin-bottom: 0;">- Rajesh Kumar</p>
                    <small style="color: #666;">New Delhi</small>
                </div>
            </div>
            <div class="col-third">
                <div class="card" style="padding: 25px;">
                    <p style="margin-top: 0;">"The 24/7 chatbot is amazing. Got answers to all my questions instantly. Highly recommended!"</p>
                    <p style="color: #1a237e; font-weight: 600; margin-bottom: 0;">- Priya Sharma</p>
                    <small style="color: #666;">Mumbai</small>
                </div>
            </div>
            <div class="col-third">
                <div class="card" style="padding: 25px;">
                    <p style="margin-top: 0;">"Finally a government service that's user-friendly and works smoothly. Great work!"</p>
                    <p style="color: #1a237e; font-weight: 600; margin-bottom: 0;">- Amit Patel</p>
                    <small style="color: #666;">Bangalore</small>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section style="background-color: #1a237e; color: white; padding: 60px 15px; text-align: center;">
        <div class="container">
            <h2>Ready to Find Your Government Schemes?</h2>
            <p style="font-size: 18px; margin-bottom: 30px;">Join thousands of citizens already discovering schemes they're eligible for.</p>
            <a href="register.php" class="btn btn-primary" style="background-color: #ff9800; border: none; padding: 12px 40px; font-size: 16px;">Get Started Today</a>
        </div>
    </section>

    <!-- Footer -->
    <footer style="background-color: #0d1750; color: white; padding: 30px 15px; text-align: center;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
            <p style="font-size: 12px; opacity: 0.8;">
                <a href="about.php" style="color: #ff9800;">About Us</a> | 
                <a href="#" style="color: #ff9800;">Privacy Policy</a> | 
                <a href="#" style="color: #ff9800;">Terms of Service</a> | 
                <a href="#" style="color: #ff9800;">Contact Us</a>
            </p>
        </div>
    </footer>

    <script src="js/chatbot.js"></script>
</body>
</html>
