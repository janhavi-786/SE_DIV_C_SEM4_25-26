<?php
// View Specific Search Results
session_start();
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db_config.php';

if (!isLoggedIn()) {
    header("Location: /FindMyScheme/login.php");
    exit();
}

$searchId = (int) ($_GET['search_id'] ?? 0);
$userId = (int) $_SESSION['user_id'];

// Verify the search belongs to the user
$searchSql = "SELECT * FROM search_history WHERE id = $searchId AND user_id = $userId";
$searchResult = $conn->query($searchSql);

if ($searchResult->num_rows == 0) {
    header("Location: search-history.php");
    exit();
}

$searchData = $searchResult->fetch_assoc();

// Get the schemes for this search
$schemesSql = "SELECT s.*, usa.confidence_level, usa.eligibility_details 
               FROM schemes s
               JOIN user_scheme_applications usa ON s.id = usa.scheme_id
               WHERE usa.search_id = $searchId AND usa.user_id = $userId";
$schemesResult = $conn->query($schemesSql);

$schemes = [];
while ($row = $schemesResult->fetch_assoc()) {
    $details = json_decode($row['eligibility_details'], true);
    $schemes[] = [
        'id' => $row['id'],
        'name' => $row['name'],
        'description' => $row['description'],
        'benefits' => $row['benefits'],
        'category' => $row['category'],
        'apply_url' => $row['apply_url'],
        'confidence' => $row['confidence_level'],
        'reasons' => $details['reasons'] ?? []
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
    <style>
        .confidence-box {
            padding: 8px 15px;
            border-radius: 12px;
            border: 1px solid #ddd;
            text-align: right;
        }
        .confidence-label { font-size: 11px; text-transform: uppercase; font-weight: bold; }
        .confidence-value { font-size: 14px; font-weight: bold; display: flex; align-items: center; gap: 8px; justify-content: flex-end; }
        .confidence-dot { width: 8px; height: 8px; border-radius: 50%; }
        .confidence-sub { font-size: 10px; opacity: 0.8; }
        
        .scheme-card-new {
            background: white;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.06);
            border: 1px solid #eee;
        }
        .card-header-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px; }
        .scheme-title { font-size: 1.4rem; font-weight: 700; color: #1a237e; margin-bottom: 8px; }
        .category-pill { background: #e8eaf6; color: #1a237e; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; display: inline-block; font-weight: 600; }
        
        .benefits-section { margin: 20px 0; padding: 15px; background: #f0f4ff; border-radius: 12px; }
        .benefits-title { font-weight: 700; color: #1a237e; margin-bottom: 10px; }
        .benefits-list { padding-left: 20px; margin: 0; }
        
        .eligibility-toggle { border-top: 1px solid #eee; margin-top: 20px; padding-top: 15px; }
        .eligibility-header { color: #666; font-size: 0.9rem; cursor: pointer; font-weight: 600; }
        .eligibility-content { display: block; margin-top: 10px; }
        .reason-item { font-size: 0.9rem; color: #444; margin-bottom: 5px; }
        
        .card-actions { display: flex; gap: 12px; margin-top: 25px; }
        .btn-learn { border: 1px solid #1a237e; color: #1a237e; padding: 10px 20px; border-radius: 8px; text-decoration: none; font-weight: 600; flex: 1; text-align: center; }
        .btn-learn:hover { background: #f5f5f5; }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="search-history.php">History</a>
                    <a href="php/logout.php" class="btn btn-primary btn-small">Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 15px;">
        <div style="margin-bottom: 30px;">
            <a href="search-history.php" style="color: #1a237e; text-decoration: none; font-weight: 600;">← Back to History</a>
            <h1 style="color: #1a237e; margin-top: 15px;">Results for Search: <?php echo date('d M Y, h:i A', strtotime($searchData['created_at'])); ?></h1>
        </div>

        <?php if (count($schemes) > 0): ?>
            <?php foreach ($schemes as $scheme): ?>
                <?php 
                    $confidence = $scheme['confidence'];
                    $confidenceColor = '#1a237e';
                    $confidenceBg = '#f5f5f5';
                    $confidenceText = 'Check Details';
                    
                    if ($confidence == 'high') { $confidenceColor = '#2e7d32'; $confidenceBg = '#e8f5e9'; $confidenceText = 'Very Likely Eligible'; }
                    elseif ($confidence == 'medium') { $confidenceColor = '#f57c00'; $confidenceBg = '#fff3e0'; $confidenceText = 'Likely Eligible'; }
                    elseif ($confidence == 'low') { $confidenceColor = '#d32f2f'; $confidenceBg = '#ffebee'; $confidenceText = 'May be Eligible'; }
                ?>
                <div class="scheme-card-new">
                    <div class="card-header-row">
                        <div>
                            <div class="scheme-title"><?php echo htmlspecialchars($scheme['name']); ?></div>
                            <div class="category-pill"><?php echo htmlspecialchars($scheme['category'] ?: 'General'); ?></div>
                        </div>
                        <div class="confidence-box" style="background-color: <?php echo $confidenceBg; ?>; border-color: <?php echo $confidenceColor; ?>40;">
                            <div class="confidence-label" style="color: <?php echo $confidenceColor; ?>">Confidence Level</div>
                            <div class="confidence-value" style="color: <?php echo $confidenceColor; ?>">
                                <span class="confidence-dot" style="background-color: <?php echo $confidenceColor; ?>; box-shadow: 0 0 0 4px <?php echo $confidenceColor; ?>33;"></span>
                                <?php echo strtoupper($confidence); ?>
                            </div>
                            <div class="confidence-sub" style="color: <?php echo $confidenceColor; ?>"><?php echo $confidenceText; ?></div>
                        </div>
                    </div>

                    <div class="scheme-description">
                        <?php echo htmlspecialchars($scheme['description']); ?>
                    </div>
                    
                    <div class="benefits-section">
                        <div class="benefits-title">👍 Benefits</div>
                        <ul class="benefits-list">
                            <?php 
                                $bText = $scheme['benefits'];
                                if ($bText === 'Extracted via Selenium from myscheme') {
                                    $bText = "Financial assistance and support provided by the government.\nVisit the official portal for a comprehensive list of benefits.";
                                }
                                $benefits = explode("\n", $bText);
                                foreach ($benefits as $b) {
                                    $bt = trim(ltrim($b, "- "));
                                    if (!empty($bt)) {
                                        echo "<li>" . htmlspecialchars($bt) . "</li>";
                                    }
                                }
                            ?>
                        </ul>
                    </div>

                    <div class="eligibility-toggle">
                        <div class="eligibility-header">❓ Why Am I Eligible?</div>
                        <div class="eligibility-content">
                            <?php foreach ($scheme['reasons'] as $reason): ?>
                                <div class="reason-item">
                                    <span style="color: #666;"><?php echo htmlspecialchars($reason); ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="card-actions">
                        <a href="scheme-details.php?id=<?php echo $scheme['id']; ?>" class="btn-learn">Learn More</a>
                        <a href="<?php echo htmlspecialchars($scheme['apply_url'] ?: '#'); ?>" target="_blank" class="btn btn-primary">Apply Now</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align: center; padding: 40px; background: #f9f9f9; border-radius: 12px;">
                <h3>No schemes found for this search.</h3>
            </div>
        <?php endif; ?>
    </div>

    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>
    <script src="js/chatbot.js"></script>
</body>
</html>
