<?php
// User Details Form with Session Protection
session_start();
require_once __DIR__ . '/includes/auth.php';

if (!isLoggedIn()) {
    header("Location: /FindMyScheme/login.html");
    exit();
}

$mode = isset($_GET['mode']) ? $_GET['mode'] : 'self';
$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="profile.php">Profile</a>
                    <a href="php/logout.php" class="btn btn-primary btn-small">Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Mode Indicator -->
    <?php if ($mode === 'assisted'): ?>
    <div style="background-color: #e3f2fd; padding: 15px; text-align: center; border-bottom: 2px solid #ff9800;">
        <div class="container">
            <strong style="color: #1a237e;">🤖 Assisted Mode Active</strong> - The chatbot will guide you through each step!
        </div>
    </div>
    <?php endif; ?>

    <!-- User Details Form -->
    <!-- SELF MODE CONTAINER -->
    <div id="selfModeContainer" class="form-container" style="display: <?php echo $mode === 'self' ? 'block' : 'none'; ?>;">
        <h2 style="text-align: center; margin-bottom: 10px;">Tell Us About Yourself</h2>
        <p style="text-align: center; color: #666; margin-bottom: 30px;">
            This helps us find the best schemes for you. All information is kept private and secure.
        </p>

        <form id="userDetailsForm">
            <!-- Section 1: Basic Information -->
            <div class="form-section">
                <h3>📋 Basic Information</h3>
                
                <div class="form-group">
                    <label for="age">Age *</label>
                    <input type="number" id="age" name="age" placeholder="Your age" min="1" max="120" value="<?php echo htmlspecialchars($user['age'] ?? ''); ?>" required>
                    <div class="form-error" id="ageError"></div>
                </div>

                <div class="form-group">
                    <label for="state">State of Residence *</label>
                    <select id="state" name="state" required>
                        <option value="">Select your state</option>
                        <?php
                        $states = [
                            "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
                            "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
                            "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur",
                            "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan",
                            "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh",
                            "Uttarakhand", "West Bengal"
                        ];
                        foreach ($states as $state) {
                            $selected = ($user['state'] === $state) ? 'selected' : '';
                            echo "<option value=\"$state\" $selected>$state</option>";
                        }
                        ?>
                    </select>
                    <div class="form-error" id="stateError"></div>
                </div>
            </div>

            <!-- Section 2: Financial Information -->
            <div class="form-section">
                <h3>💰 Financial Information</h3>
                
                <div class="form-group">
                    <label for="income">Annual Income (in ₹) *</label>
                    <input type="number" id="income" name="income" placeholder="0" min="0" step="1000" value="<?php echo htmlspecialchars($user['income'] ?? ''); ?>" required>
                    <small style="color: #666; margin-top: 5px;">Enter your total annual household income</small>
                    <div class="form-error" id="incomeError"></div>
                </div>
            </div>

            <!-- Section 3: Additional Information -->
            <div class="form-section">
                <h3>👤 Additional Information</h3>
                
                <div class="form-group">
                    <label for="caste">Caste Category (Optional)</label>
                    <select id="caste" name="caste">
                        <option value="">Select category</option>
                        <?php
                        $castes = ["General", "OBC", "SC", "ST"];
                        foreach ($castes as $caste) {
                            $selected = ($user['caste'] === $caste) ? 'selected' : '';
                            echo "<option value=\"$caste\" $selected>$caste" . ($caste !== 'General' ? ' - ' . ($caste === 'OBC' ? 'Other Backward Class' : ($caste === 'SC' ? 'Scheduled Caste' : 'Scheduled Tribe')) : '') . "</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="occupation">Occupation (Optional)</label>
                    <select id="occupation" name="occupation">
                        <option value="">Select occupation</option>
                        <?php
                        $occupations = ["Farmer", "Student", "Unemployed", "Self-employed", "Salaried", "Retired", "Housewife", "Other"];
                        foreach ($occupations as $occ) {
                            $selected = ($user['occupation'] === $occ) ? 'selected' : '';
                            echo "<option value=\"$occ\" $selected>$occ</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div id="errorMessage" class="alert alert-error" style="display: none; margin-top: 20px;"></div>
            <div id="successMessage" class="alert alert-success" style="display: none; margin-top: 20px;"></div>

            <!-- Form Buttons -->
            <div class="form-buttons">
                <a href="mode-selection.php" class="btn btn-outline">Back</a>
                <button type="submit" class="btn btn-primary">Find My Schemes</button>
            </div>
        </form>
    </div>

    <!-- ASSISTED MODE CONTAINER -->
    <div id="assistedModeContainer" class="form-container" style="display: <?php echo $mode === 'assisted' ? 'block' : 'none'; ?>;">
        <div class="wizard-header">
            <h2 style="text-align: center; margin-bottom: 20px;">🤖 Assisted Scheme Finder</h2>
            <div class="progress-bar-container">
                <div class="progress-bar" id="wizardProgressBar" style="width: 0%"></div>
            </div>
            <p id="stepIndicator" style="text-align: center; color: #666; margin-top: 10px; font-weight: 600;">Step 1 of 5</p>
        </div>

        <div id="wizardContent" class="wizard-content">
            <!-- Dynamic Questions will be injected here -->
        </div>

        <!-- Review Screen (Hidden by default) -->
        <div id="reviewScreen" style="display: none;">
            <h3 style="color: #1a237e; margin-bottom: 20px;">Please Review Your Details</h3>
            <div class="review-summary" id="reviewSummary">
                <!-- Summary items injected here -->
            </div>
        </div>

        <div class="wizard-controls">
            <button id="wizardBackBtn" class="btn btn-outline" style="visibility: hidden;">Back</button>
            <button id="wizardNextBtn" class="btn btn-primary">Next</button>
            <button id="wizardSubmitBtn" class="btn btn-success" style="display: none;">Confirm & Find Schemes</button>
        </div>
    </div>

    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay" style="display: none;">
        <div class="spinner"></div>
        <h3>Finding the best schemes for you...</h3>
        <p>Analyzing your profile against eligibility criteria</p>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Store mode in sessionStorage for chatbot
        sessionStorage.setItem('assistedMode', '<?php echo $mode === 'assisted' ? 'true' : 'false'; ?>');
    </script>
    <script src="js/validation.js"></script>
    <script src="js/user-details.js"></script>
    <?php if ($mode === 'assisted'): ?>
    <script src="js/assisted-mode.js"></script>
    <?php endif; ?>
    <script src="js/chatbot.js"></script>
</body>
</html>
