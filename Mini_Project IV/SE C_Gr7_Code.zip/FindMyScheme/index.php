<?php
// Home page (session-aware)
session_start();
require_once __DIR__ . '/includes/auth.php';

$loggedIn = isLoggedIn();
$user = $loggedIn ? getCurrentUser() : null;

// Get platform stats for home page visibility
$totalSchemesResult = $conn->query("SELECT COUNT(*) as total FROM schemes");
$totalSchemes = $totalSchemesResult ? $totalSchemesResult->fetch_assoc()['total'] : 0;

$totalAppsResult = $conn->query("SELECT COUNT(*) as total FROM user_scheme_applications");
$totalApps = $totalAppsResult ? $totalAppsResult->fetch_assoc()['total'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FindMyScheme - Find Government Schemes for You</title>
    <link rel="stylesheet" href="css/main.css">
    <style>
        /* Ensure scheme cards stay in single row on larger screens */
        @media (min-width: 769px) {
            .schemes-row .col-third {
                flex: 0 0 calc(33.333% - 20px) !important;
                min-width: 280px;
            }
        }
    </style>
</head>
<body>
    <!-- Header/Navigation -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="about.php">About</a>
                    <div class="nav-auth">
                        <?php if ($loggedIn): ?>
                            <a href="dashboard.php" class="btn btn-primary btn-small">Dashboard</a>
                            <a href="profile.php" class="btn btn-outline btn-small">Profile</a>
                            <a href="php/logout.php" class="btn btn-outline btn-small">Logout</a>
                        <?php else: ?>
                            <a href="login.php" class="btn btn-primary btn-small">Login</a>
                            <a href="register.php" class="btn btn-outline btn-small">Register</a>
                        <?php endif; ?>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Discover Government Schemes Suited for You</h1>
                <p>FindMyScheme helps you find eligible government schemes based on your profile. No more confusion, no more manual searching – just personalized recommendations.</p>
                <div class="hero-cta">
                    <?php if ($loggedIn): ?>
                        <a href="dashboard.php" class="btn btn-primary">Dashboard</a>
                        <a href="mode-selection.php" class="btn btn-outline" style="color: white; border-color: white;">Find My Schemes</a>
                    <?php else: ?>
                        <a href="register.php" class="btn btn-primary">Get Started</a>
                        <a href="login.php" class="btn btn-outline" style="color: white; border-color: white;">Login</a>
                    <?php endif; ?>
                </div>

                <!-- Platform Stats Row -->
                <div style="display: flex; gap: 40px; justify-content: center; margin-top: 50px; flex-wrap: wrap; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 30px;">
                    <div style="text-align: center;">
                        <div style="font-size: 2.5rem; font-weight: 800; color: #ff9800;"><?php echo number_format($totalSchemes); ?>+</div>
                        <div style="font-size: 0.9rem; color: rgba(255,255,255,0.8); text-transform: uppercase; letter-spacing: 1px;">Live Schemes</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 2.5rem; font-weight: 800; color: #4caf50;"><?php echo number_format($totalApps); ?>+</div>
                        <div style="font-size: 0.9rem; color: rgba(255,255,255,0.8); text-transform: uppercase; letter-spacing: 1px;">Successful Matches</div>
                    </div>
                    <div style="text-align: center;">
                        <div style="font-size: 2.5rem; font-weight: 800; color: #2196f3;">24/7</div>
                        <div style="font-size: 0.9rem; color: rgba(255,255,255,0.8); text-transform: uppercase; letter-spacing: 1px;">AI Assistance</div>
                    </div>
                </div>
                
                <?php if ($loggedIn && $user): ?>
                    <p style="margin-top: 20px; opacity: 0.9;">Welcome back, <strong><?php echo htmlspecialchars($user['name']); ?></strong></p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Latest Schemes Section (kept from existing design) -->
    <section style="background-color: #f0f4ff; padding: 60px 15px;">
        <div class="container">
            <h2 style="text-align: center; margin-bottom: 50px; color: #1a237e;">Latest Government Schemes</h2>
            <div class="row schemes-row" style="flex-wrap: nowrap; justify-content: center; display: flex;">
                <div class="col-third" style="flex: 0 0 calc(33.333% - 20px); min-width: 280px;">
                    <div class="card" style="padding: 25px; border-left: 5px solid #ff9800;">
                        <h3 style="color: #1a237e; margin-top: 0;">PM Kisan Samman Nidhi</h3>
                        <p style="color: #666; font-size: 14px;">Direct income support to farmers across India</p>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
                            <span style="background-color: #2e7d32; color: white; padding: 5px 10px; border-radius: 4px; font-size: 12px;">Active</span>
                            <a href="about.html" style="color: #1a237e; font-weight: 600; text-decoration: none;">Learn More →</a>
                        </div>
                    </div>
                </div>
                <div class="col-third" style="flex: 0 0 calc(33.333% - 20px); min-width: 280px;">
                    <div class="card" style="padding: 25px; border-left: 5px solid #ff9800;">
                        <h3 style="color: #1a237e; margin-top: 0;">Pradhan Mantri Awas Yojana</h3>
                        <p style="color: #666; font-size: 14px;">Affordable housing scheme for all</p>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
                            <span style="background-color: #2e7d32; color: white; padding: 5px 10px; border-radius: 4px; font-size: 12px;">Active</span>
                            <a href="about.html" style="color: #1a237e; font-weight: 600; text-decoration: none;">Learn More →</a>
                        </div>
                    </div>
                </div>
                <div class="col-third" style="flex: 0 0 calc(33.333% - 20px); min-width: 280px;">
                    <div class="card" style="padding: 25px; border-left: 5px solid #ff9800;">
                        <h3 style="color: #1a237e; margin-top: 0;">Skill India Mission</h3>
                        <p style="color: #666; font-size: 14px;">Training and skill development programs</p>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
                            <span style="background-color: #2e7d32; color: white; padding: 5px 10px; border-radius: 4px; font-size: 12px;">Active</span>
                            <a href="about.html" style="color: #1a237e; font-weight: 600; text-decoration: none;">Learn More →</a>
                        </div>
                    </div>
                </div>
            </div>
            <div style="text-align: center; margin-top: 40px;">
                <p style="color: #666; margin-bottom: 15px;">Explore schemes available on FindMyScheme</p>
                <?php if ($loggedIn): ?>
                    <a href="mode-selection.php" class="btn btn-primary" style="padding: 12px 30px;">Find My Scheme</a>
                <?php else: ?>
                    <a href="register.html" class="btn btn-primary" style="padding: 12px 30px;">Register to See All Schemes</a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
            <p style="font-size: 12px; opacity: 0.8;">
                <a href="about.html" style="color: #ff9800;">About Us</a> | 
                <a href="#" style="color: #ff9800;">Privacy Policy</a> | 
                <a href="#" style="color: #ff9800;">Terms of Service</a> | 
                <a href="#" style="color: #ff9800;">Contact Us</a>
            </p>
        </div>
    </footer>

    <script src="js/chatbot.js"></script>
</body>
</html>

