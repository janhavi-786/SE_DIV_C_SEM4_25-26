<?php
// Scheme details page (login required)
session_start();
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db_config.php';

if (!isLoggedIn()) {
    header("Location: /FindMyScheme/login.html");
    exit();
}

$schemeId = (int)($_GET['id'] ?? 0);
if ($schemeId <= 0) {
    header("Location: /FindMyScheme/results.php");
    exit();
}

$schemeQuery = "
    SELECT
        s.*,
        er.age_min, er.age_max, er.income_max, er.caste_category, er.states, er.occupations, er.other_criteria
    FROM schemes s
    LEFT JOIN eligibility_rules er ON s.id = er.scheme_id
    WHERE s.id = $schemeId
    LIMIT 1
";
$res = $conn->query($schemeQuery);
if (!$res || $res->num_rows === 0) {
    header("Location: /FindMyScheme/results.php");
    exit();
}
$scheme = $res->fetch_assoc();

$applyUrl = $scheme['apply_url'] ?? '';
$docsText = $scheme['required_documents'] ?? '';

// Build documents list
$docs = [];
if (!empty(trim($docsText))) {
    $lines = preg_split("/\r\n|\n|\r/", $docsText);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line !== '') $docs[] = $line;
    }
} else {
    // sensible default checklist
    $docs = [
        "Aadhaar Card / Identity Proof",
        "Address Proof",
        "Income Certificate",
        "Bank Passbook / Account details",
        "Passport size photo",
    ];
    if (($scheme['category'] ?? '') === 'Education') {
        $docs[] = "Student ID / School or College certificate";
    }
    if (($scheme['category'] ?? '') === 'Healthcare') {
        $docs[] = "Ration Card / BPL Card (if applicable)";
    }
}

function fmtMoney($v) {
    if ($v === null || $v === '') return '';
    return '₹' . number_format((float)$v);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($scheme['name']); ?> - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="results.php">Results</a>
                    <a href="profile.php">Profile</a>
                    <a href="php/logout.php" class="btn btn-primary btn-small">Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <section style="background-color: #e3f2fd; padding: 40px 15px;">
        <div class="container">
            <div class="card" style="border-left-color: #ff9800;">
                <div class="card-header" style="display:flex; justify-content:space-between; align-items:center; gap: 15px;">
                    <div>
                        <h2 style="margin:0;"><?php echo htmlspecialchars($scheme['name']); ?></h2>
                        <div style="margin-top: 6px;">
                            <span class="scheme-category"><?php echo htmlspecialchars($scheme['category'] ?: 'General'); ?></span>
                        </div>
                    </div>
                    <div style="display:flex; gap: 10px; flex-wrap: wrap;">
                        <a class="btn btn-outline" href="results.php">← Back</a>
                        <?php if (!empty($applyUrl)): ?>
                            <a class="btn btn-primary" href="<?php echo htmlspecialchars($applyUrl); ?>" target="_blank" rel="noopener noreferrer">Apply Now</a>
                        <?php else: ?>
                            <a class="btn btn-primary" href="#" onclick="alert('Apply link not available. Please apply via the official government portal for this scheme.'); return false;">Apply Now</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <p style="color:#666; margin-top:0;"><?php echo nl2br(htmlspecialchars($scheme['description'] ?? '')); ?></p>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 30px 15px;">
        <div class="container" style="display:grid; grid-template-columns: 1.2fr 0.8fr; gap: 20px;">
            <div>
                <div class="card" style="border-left-color:#2e7d32;">
                    <div class="card-header">💰 Benefits</div>
                    <div class="card-body">
                        <?php if (!empty(trim($scheme['benefits'] ?? ''))): ?>
                            <ul style="list-style:none; padding:0; margin:0;">
                                <?php 
                                    $benefitsText = $scheme['benefits'];
                                    if ($benefitsText === 'Extracted via Selenium from myscheme') {
                                        $benefitsText = "Financial assistance and support provided by the government.\nVisit the official portal for a comprehensive list of benefits.";
                                    }
                                    foreach (preg_split("/\r\n|\n|\r/", $benefitsText) as $b): ?>
                                    <?php $b = trim($b); if ($b === '') continue; ?>
                                    <li style="padding: 8px 0; padding-left: 25px; position: relative;">
                                        <span style="position: absolute; left: 0; color: #2e7d32;">✓</span>
                                        <?php echo htmlspecialchars($b); ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>
                            <p style="color:#666; margin:0;">Benefits information will be updated soon.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card" style="margin-top: 20px; border-left-color:#1a237e;">
                    <div class="card-header">✅ Eligibility (Overview)</div>
                    <div class="card-body" style="color:#444;">
                        <ul style="margin:0; padding-left: 18px;">
                            <?php if ($scheme['age_min'] !== null || $scheme['age_max'] !== null): ?>
                                <li>Age: <?php echo (int)($scheme['age_min'] ?? 0); ?> to <?php echo (int)($scheme['age_max'] ?? 120); ?> years</li>
                            <?php endif; ?>
                            <?php if ($scheme['income_max'] !== null): ?>
                                <li>Income: up to <?php echo fmtMoney($scheme['income_max']); ?></li>
                            <?php endif; ?>
                            <?php if (!empty($scheme['caste_category'] ?? '')): ?>
                                <li>Category: <?php echo htmlspecialchars($scheme['caste_category']); ?></li>
                            <?php endif; ?>
                            <?php if (!empty($scheme['states'] ?? '')): ?>
                                <li>States: <?php echo htmlspecialchars($scheme['states']); ?></li>
                            <?php endif; ?>
                            <?php if (!empty($scheme['occupations'] ?? '')): ?>
                                <li>Occupations: <?php echo htmlspecialchars($scheme['occupations']); ?></li>
                            <?php endif; ?>
                            <?php 
                                $other = trim($scheme['other_criteria'] ?? '');
                                if ($other === 'Other: Refer to official portal for detailed eligibility rules.') {
                                    $other = 'Refer to official portal for detailed eligibility rules.';
                                }
                                if (!empty($other)): ?>
                                <li>Other: <?php echo htmlspecialchars($other); ?></li>
                            <?php endif; ?>
                            <?php if (
                                $scheme['age_min'] === null && $scheme['age_max'] === null &&
                                $scheme['income_max'] === null && empty($scheme['caste_category'] ?? '') &&
                                empty($scheme['states'] ?? '') && empty($scheme['occupations'] ?? '') &&
                                empty(trim($scheme['other_criteria'] ?? ''))
                            ): ?>
                                <li>Eligibility rules will be updated soon.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

                <div class="card" style="margin-top: 20px; border-left-color:#e91e63;">
                    <div class="card-header">📋 Application Process</div>
                    <div class="card-body">
                        <div style="display: flex; flex-direction: column; gap: 15px;">
                            <div style="display: flex; align-items: flex-start; gap: 12px;">
                                <div style="background: #e91e63; color: white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; flex-shrink: 0;">1</div>
                                <div>
                                    <strong>Gather Required Documents</strong>
                                    <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Collect all documents listed in the "Required Documents" section.</p>
                                </div>
                            </div>
                            <div style="display: flex; align-items: flex-start; gap: 12px;">
                                <div style="background: #e91e63; color: white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; flex-shrink: 0;">2</div>
                                <div>
                                    <strong>Visit Official Portal</strong>
                                    <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Click "Apply Now" to access the official government application portal.</p>
                                </div>
                            </div>
                            <div style="display: flex; align-items: flex-start; gap: 12px;">
                                <div style="background: #e91e63; color: white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; flex-shrink: 0;">3</div>
                                <div>
                                    <strong>Fill Application Form</strong>
                                    <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Complete the online application form with accurate information.</p>
                                </div>
                            </div>
                            <div style="display: flex; align-items: flex-start; gap: 12px;">
                                <div style="background: #e91e63; color: white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; flex-shrink: 0;">4</div>
                                <div>
                                    <strong>Upload Documents</strong>
                                    <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Upload scanned copies of all required documents in the specified format.</p>
                                </div>
                            </div>
                            <div style="display: flex; align-items: flex-start; gap: 12px;">
                                <div style="background: #e91e63; color: white; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: bold; flex-shrink: 0;">5</div>
                                <div>
                                    <strong>Submit & Track</strong>
                                    <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">Submit your application and save the reference number for tracking.</p>
                                </div>
                            </div>
                        </div>
                        <div style="margin-top: 15px; padding: 12px; background: #fff3e0; border-radius: 6px; border-left: 4px solid #ff9800;">
                            <strong style="color: #e65100;">💡 Pro Tip:</strong>
                            <span style="color: #666; font-size: 14px;">Keep digital and physical copies of all documents. Application processing time varies by scheme and state.</span>
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <div class="card" style="border-left-color:#ff9800;">
                    <div class="card-header">📄 Required Documents</div>
                    <div class="card-body">
                        <ul style="list-style:none; padding:0; margin:0;">
                            <?php foreach ($docs as $d): ?>
                                <li style="padding: 8px 0; padding-left: 25px; position: relative;">
                                    <span style="position: absolute; left: 0; color: #ff9800;">•</span>
                                    <?php echo htmlspecialchars($d); ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <div style="margin-top: 12px; font-size: 12px; color:#666;">
                            Note: Document list may vary by state/department. Always verify on the official portal.
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 40px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>

    <script>
        function showApplicationInfo() {
            const schemeName = "<?php echo addslashes($scheme['name']); ?>";
            const message = `To apply for "${schemeName}":\n\n` +
                          `1. Visit your state's official government portal\n` +
                          `2. Look for the scheme under relevant department\n` +
                          `3. Follow the application process outlined above\n` +
                          `4. Contact local government office if needed\n\n` +
                          `Note: Application links are updated regularly. Check back later for direct links.`;
            
            alert(message);
        }
    </script>
    <script src="js/chatbot.js"></script>
</body>
</html>

