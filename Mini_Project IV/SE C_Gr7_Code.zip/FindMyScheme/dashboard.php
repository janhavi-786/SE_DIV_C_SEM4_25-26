<?php
// Dashboard with Session Protection
session_start();
require_once __DIR__ . '/includes/auth.php';

if (!isLoggedIn()) {
    header("Location: /FindMyScheme/login.php");
    exit();
}

// Get user info
$user = getCurrentUser();

// Get platform stats
$totalSchemesResult = $conn->query("SELECT COUNT(*) as total FROM schemes");
$totalSchemes = $totalSchemesResult ? $totalSchemesResult->fetch_assoc()['total'] : 0;

$totalAppsResult = $conn->query("SELECT COUNT(*) as total FROM user_scheme_applications");
$totalApps = $totalAppsResult ? $totalAppsResult->fetch_assoc()['total'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="profile.php">Profile</a>
                    <a href="php/logout.php" class="btn btn-primary btn-small">Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Dashboard Container -->
    <div class="container" style="padding: 40px 15px;">
        <div class="card">
            <div class="card-header">👋 Welcome to Your Dashboard</div>
            <div class="card-body">
                <p id="userGreeting">Welcome back, <?php echo htmlspecialchars($user['name']); ?>! 👋</p>
                <div style="display: flex; gap: 20px; margin-top: 15px; flex-wrap: wrap;">
                    <div style="background: #e3f2fd; padding: 15px; border-radius: 8px; flex: 1; min-width: 150px; border-left: 4px solid #1a237e;">
                        <div style="font-size: 0.8rem; color: #1a237e; font-weight: 700; text-transform: uppercase;">Total Schemes</div>
                        <div style="font-size: 1.5rem; font-weight: 800; color: #1a237e;"><?php echo number_format($totalSchemes); ?>+</div>
                    </div>
                    <div style="background: #e8f5e9; padding: 15px; border-radius: 8px; flex: 1; min-width: 150px; border-left: 4px solid #2e7d32;">
                        <div style="font-size: 0.8rem; color: #2e7d32; font-weight: 700; text-transform: uppercase;">Successful Matches</div>
                        <div style="font-size: 1.5rem; font-weight: 800; color: #2e7d32;"><?php echo number_format($totalApps); ?>+</div>
                    </div>
                </div>
                <p style="color: #666; margin-top: 20px;">
                    Use the options below to get started with finding government schemes suited for you.
                </p>
            </div>
        </div>

        <!-- Quick Actions -->
        <div style="margin-top: 40px;">
            <h2 style="margin-bottom: 30px;">What Would You Like to Do?</h2>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
                <!-- Find Schemes Card -->
                <div class="card" style="border-left-color: #ff9800; cursor: pointer;" onclick="window.location.href='mode-selection.php'">
                    <div style="font-size: 2rem; margin-bottom: 15px;">🔍</div>
                    <h3>Find My Schemes</h3>
                    <p style="color: #666; margin-bottom: 20px;">
                        Discover government schemes you're eligible for based on your profile.
                    </p>
                    <a href="mode-selection.php" class="btn btn-primary btn-block">Get Started</a>
                </div>

                <!-- View History Card -->
                <div class="card" style="border-left-color: #2e7d32; cursor: pointer;" onclick="window.location.href='search-history.php'">
                    <div style="font-size: 2rem; margin-bottom: 15px;">📜</div>
                    <h3>View Search History</h3>
                    <p style="color: #666; margin-bottom: 20px;">
                        See all your previous scheme searches and saved results.
                    </p>
                    <a href="search-history.php" class="btn btn-success btn-block">Open History</a>
                </div>

                <!-- Profile Card -->
                <div class="card" style="border-left-color: #1a237e; cursor: pointer;">
                    <div style="font-size: 2rem; margin-bottom: 15px;">⚙️</div>
                    <h3>Manage Profile</h3>
                    <p style="color: #666; margin-bottom: 20px;">
                        Update your personal information and preferences.
                    </p>
                    <a href="profile.php" class="btn btn-outline btn-block">Open Profile</a>
                </div>
            </div>
        </div>

        <!-- Recent Schemes Section -->
        <div style="margin-top: 50px; background-color: #f0f4ff; padding: 30px; border-radius: 8px;">
            <h3 style="margin-bottom: 20px;">📚 Featured Schemes</h3>
            <p style="color: #666; margin-bottom: 20px;">
                Here are some of the most popular government schemes available:
            </p>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                <div class="card" style="border-left-color: #2e7d32;">
                    <h4>Pradhan Mantri Jan Dhan Yojana</h4>
                    <p style="font-size: 13px; color: #666;">Financial inclusion for all citizens</p>
                </div>
                <div class="card" style="border-left-color: #2e7d32;">
                    <h4>PM-JAY: Ayushman Bharat</h4>
                    <p style="font-size: 13px; color: #666;">Free health insurance coverage</p>
                </div>
                <div class="card" style="border-left-color: #2e7d32;">
                    <h4>Sukanya Samriddhi Yojana</h4>
                    <p style="font-size: 13px; color: #666;">Savings scheme for the girl child</p>
                </div>
            </div>
        </div>

        <!-- Help Section -->
        <div style="margin-top: 50px; background-color: #fff3cd; padding: 30px; border-radius: 8px; border-left: 4px solid #ff9800;">
            <h3 style="color: #856404; margin-bottom: 15px;">💡 Need Help?</h3>
            <p style="color: #856404;">
                Use our chatbot (bottom right) to answer your questions. You can also check the FAQ section or contact our support team.
            </p>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/chatbot.js"></script>
</body>
</html>
