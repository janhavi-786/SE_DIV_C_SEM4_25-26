document.addEventListener('DOMContentLoaded', function () {
    // Only run if assisted mode container exists
    if (!document.getElementById('assistedModeContainer')) return;

    // Configuration for steps
    const steps = [
        {
            id: 'age',
            question: "Let's start with your age. How old are you?",
            type: 'number',
            placeholder: 'Enter your age (e.g., 25)',
            icon: '',
            validation: (val) => {
                const age = parseInt(val);
                if (!val) return "Please enter your age.";
                if (isNaN(age) || age < 1 || age > 120) return "Please enter a valid age between 1 and 120.";
                return null;
            }
        },
        {
            id: 'state',
            question: "Which state do you currently reside in?",
            type: 'select',
            options: [
                "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
                "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
                "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur",
                "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan",
                "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh",
                "Uttarakhand", "West Bengal"
            ],
            icon: '📍',
            validation: (val) => !val ? "Please select your state." : null
        },
        {
            id: 'income',
            question: "What is your total annual family income?",
            type: 'number',
            placeholder: 'Enter amount in ₹ (e.g., 500000)',
            icon: '💰',
            validation: (val) => {
                if (!val) return "Please enter your income.";
                if (parseInt(val) < 0) return "Income cannot be negative.";
                return null;
            }
        },
        {
            id: 'caste',
            question: "What is your caste category? (Optional)",
            type: 'select',
            options: ["General", "OBC", "SC", "ST"],
            icon: '📋',
            validation: () => null // Optional
        },
        {
            id: 'occupation',
            question: "What is your primary occupation? (Optional)",
            type: 'select',
            options: ["Farmer", "Student", "Unemployed", "Self-employed", "Salaried", "Retired", "Housewife", "Other"],
            icon: '💼',
            validation: () => null // Optional
        }
    ];

    // State Management
    let currentStep = 0;
    let answers = JSON.parse(sessionStorage.getItem('wizardAnswers') || '{}');

    // DOM Elements
    const progressBar = document.getElementById('wizardProgressBar');
    const stepIndicator = document.getElementById('stepIndicator');
    const contentDiv = document.getElementById('wizardContent');
    const backBtn = document.getElementById('wizardBackBtn');
    const nextBtn = document.getElementById('wizardNextBtn');
    const submitBtn = document.getElementById('wizardSubmitBtn');
    const reviewScreen = document.getElementById('reviewScreen');

    // Initialize
    init();

    function init() {
        // Restore step if possible, but sanity check it
        const savedStep = parseInt(sessionStorage.getItem('currentStep') || '0');
        currentStep = Math.min(savedStep, steps.length); // Allow going up to review step

        if (currentStep === steps.length) {
            showReview();
        } else {
            renderStep(currentStep);
        }

        updateControls();
    }

    function renderStep(index) {
        const step = steps[index];
        reviewScreen.style.display = 'none';
        contentDiv.style.display = 'block';

        let inputHTML = '';

        if (step.type === 'number') {
            inputHTML = `
                <input type="number" id="wizardInput" class="wizard-input" 
                       placeholder="${step.placeholder}" 
                       value="${answers[step.id] || ''}"
                       onkeydown="if(event.key === 'Enter') document.getElementById('wizardNextBtn').click()">
            `;
        } else if (step.type === 'select') {
            const optionsHTML = step.options.map(opt =>
                `<option value="${opt}" ${answers[step.id] === opt ? 'selected' : ''}>${opt}</option>`
            ).join('');

            inputHTML = `
                <select id="wizardInput" class="wizard-input" onkeydown="if(event.key === 'Enter') document.getElementById('wizardNextBtn').click()">
                    <option value="">Select an option...</option>
                    ${optionsHTML}
                </select>
            `;
        }

        contentDiv.innerHTML = `
            <div class="step-icon">${step.icon}</div>
            <h3 class="question-text">${step.question}</h3>
            <div class="input-container">
                ${inputHTML}
                <div class="wizard-error" id="wizardError"></div>
            </div>
        `;

        // Focus input for accessibility
        setTimeout(() => {
            const input = document.getElementById('wizardInput');
            if (input) input.focus();
        }, 100);

        updateProgress();
    }

    function updateProgress() {
        const progress = ((currentStep + 1) / (steps.length + 1)) * 100;
        progressBar.style.width = `${progress}%`;
        stepIndicator.textContent = `Step ${currentStep + 1} of ${steps.length}`;
    }

    function handleNext() {
        if (currentStep >= steps.length) {
            submitForm();
            return;
        }

        const input = document.getElementById('wizardInput');
        const value = input.value.trim();
        const step = steps[currentStep];

        // Validation
        const error = step.validation(value);
        if (error) {
            document.getElementById('wizardError').textContent = error;
            input.classList.add('error');
            input.focus();
            return;
        }

        // Save answer
        answers[step.id] = value;
        sessionStorage.setItem('wizardAnswers', JSON.stringify(answers));

        // Move next
        currentStep++;
        sessionStorage.setItem('currentStep', currentStep);

        if (currentStep < steps.length) {
            renderStep(currentStep);
        } else {
            showReview();
        }
        updateControls();
    }

    function handleBack() {
        if (currentStep > 0) {
            currentStep--;
            sessionStorage.setItem('currentStep', currentStep);

            if (currentStep < steps.length) {
                renderStep(currentStep);
            } else {
                // If we were at submission, go back to review
                // If we were at review, go back to last step
                renderStep(currentStep);
            }
            updateControls();
        }
    }

    function showReview() {
        contentDiv.style.display = 'none';
        reviewScreen.style.display = 'block';

        const summaryDiv = document.getElementById('reviewSummary');
        summaryDiv.innerHTML = steps.map(step => `
            <div class="summary-item">
                <span class="label">${step.id.charAt(0).toUpperCase() + step.id.slice(1)}:</span>
                <span class="value">${answers[step.id] || 'Not provided'}</span>
                <button class="btn-link" onclick="editStep(${steps.indexOf(step)})">Edit</button>
            </div>
        `).join('');

        progressBar.style.width = '100%';
        stepIndicator.textContent = 'Review Details';
        updateControls();
    }

    window.editStep = function (index) {
        currentStep = index;
        sessionStorage.setItem('currentStep', currentStep);
        renderStep(currentStep);
        updateControls();
    };

    function updateControls() {
        backBtn.style.visibility = currentStep > 0 ? 'visible' : 'hidden';

        if (currentStep === steps.length) {
            nextBtn.style.display = 'none';
            submitBtn.style.display = 'inline-block';
        } else {
            nextBtn.style.display = 'inline-block';
            submitBtn.style.display = 'none';
        }
    }

    function submitForm() {
        // Show loading state
        document.getElementById('loadingOverlay').style.display = 'flex';

        // Fill the hidden (self mode) form with gathered data
        // This reuses the existing backend submission logic logic if we hooked into it, 
        // OR we can just simulate the submit by populating the hidden form

        const selfForm = document.getElementById('userDetailsForm');

        // Populate inputs
        for (const [key, value] of Object.entries(answers)) {
            const input = selfForm.querySelector(`[name="${key}"]`);
            if (input) input.value = value;
        }

        // Allow some time for the loading animation to be seen (UX)
        setTimeout(() => {
            // Trigger the original form submission logic
            // Since we are reusing validation.js/user-details.js logic which attaches to #userDetailsForm
            // We can just trigger the submit event, or call the existing submission code if exposed.
            // But since user-details.js likely listens to 'submit', we trigger that.

            // However, we need to ensure the form is visible to submit? No, hidden form submit is fine.
            // Let's trigger the click on the submit button of the hidden form to trigger standard validation/submission

            const submitEvent = new Event('submit', { cancelable: true });
            selfForm.dispatchEvent(submitEvent);

            // Should the original JS handle the redirect? Yes, assumed functionality.
            // If original JS fails, we might hang. But let's trust existing logic for now.
        }, 1500);
    }

    // Event Listeners
    nextBtn.addEventListener('click', handleNext);
    backBtn.addEventListener('click', handleBack);
    submitBtn.addEventListener('click', submitForm);
});
