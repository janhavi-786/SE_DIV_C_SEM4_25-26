document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('userDetailsForm');

    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();

            const errorMessage = document.getElementById('errorMessage');
            const successMessage = document.getElementById('successMessage');

            // Basic frontend validation
            // Note: assisted-mode.js already validates before filling, 
            // but self-mode needs this validation too.
            // validation.js functions might be used here if available, 
            // but we'll do quick native validation to be safe.

            const formData = new FormData(form);

            // Clear previous messages
            if (errorMessage) errorMessage.style.display = 'none';
            if (successMessage) successMessage.style.display = 'none';

            // Check if we are in assisted mode (loading overlay managed by assisted-mode.js)
            // If not, we might want to show a spinner or button loading state here.

            fetch('php/update-profile.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (successMessage) {
                            successMessage.textContent = 'Profile updated! Redirecting...';
                            successMessage.style.display = 'block';
                        }

                        // Redirect to results page
                        setTimeout(() => {
                            window.location.href = 'results.php';
                        }, 1000);
                    } else {
                        if (errorMessage) {
                            errorMessage.textContent = data.message || 'An error occurred.';
                            errorMessage.style.display = 'block';
                        }

                        // If we are in assisted mode, we need to hide the loading overlay to show the error
                        const loadingOverlay = document.getElementById('loadingOverlay');
                        if (loadingOverlay) loadingOverlay.style.display = 'none';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    if (errorMessage) {
                        errorMessage.textContent = 'A network error occurred. Please try again.';
                        errorMessage.style.display = 'block';
                    }
                    const loadingOverlay = document.getElementById('loadingOverlay');
                    if (loadingOverlay) loadingOverlay.style.display = 'none';
                });
        });
    }
});
