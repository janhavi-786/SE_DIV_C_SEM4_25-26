// Form Validation Utility Functions

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePassword(password) {
    // At least 6 characters, 1 uppercase, 1 lowercase, 1 number
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{6,}$/;
    return passwordRegex.test(password);
}

function validateAge(age) {
    return age >= 1 && age <= 120;
}

function validateIncome(income) {
    return income >= 0;
}

function clearErrors() {
    const errorElements = document.querySelectorAll('.form-error');
    errorElements.forEach(el => el.textContent = '');
}

function showError(elementId, message) {
    const errorElement = document.getElementById(elementId);
    if (errorElement) {
        errorElement.textContent = message;
    }
}

function showSuccess(elementId, message) {
    const successElement = document.getElementById(elementId);
    if (successElement) {
        successElement.style.display = 'block';
        successElement.textContent = message;
    }
}

function showErrorAlert(elementId, message) {
    const alertElement = document.getElementById(elementId);
    if (alertElement) {
        alertElement.style.display = 'block';
        alertElement.textContent = message;
    }
}

function hideErrorAlert(elementId) {
    const alertElement = document.getElementById(elementId);
    if (alertElement) {
        alertElement.style.display = 'none';
    }
}

// API Helper Functions

async function apiCall(url, method = 'GET', data = null) {
    try {
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };

        if (method !== 'GET' && data) {
            const formData = new URLSearchParams();
            for (const key in data) {
                formData.append(key, data[key]);
            }
            options.body = formData;
        }

        const response = await fetch(url, options);
        
        if (!response.ok && response.status !== 401) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error('API call error:', error);
        throw error;
    }
}

// Session Helper
function checkSession() {
    // Check if user is logged in by trying to fetch user data
    apiCall('/FindMyScheme/php/get-user.php')
        .then(response => {
            if (!response.success && response.error === 'Unauthorized') {
                // Not logged in, redirect to login
                if (window.location.pathname !== '/FindMyScheme/login.html' && 
                    window.location.pathname !== '/FindMyScheme/register.html' &&
                    window.location.pathname !== '/FindMyScheme/index.php') {
                    window.location.href = '/FindMyScheme/login.html';
                }
            }
        })
        .catch(error => {
            console.log('Session check - user not logged in');
        });
}

// Debounce function for form validation
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}
