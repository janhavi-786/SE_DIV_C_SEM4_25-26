/**
 * FindMyScheme — Scheme Guidance Assistant UI
 * Pure conversational chatbot for guidance and recommendations.
 */

(function () {
    'use strict';

    // ========== CONFIGURATION & STATE ==========
    const API_URL = '/FindMyScheme/php/chatbot-api.php';
    
    let isChatOpen = false;
    let isProcessing = false;

    // ========== INITIALIZATION ==========
    // Check if chat was open before page change
    const wasOpen = sessionStorage.getItem('fms-chatbot-open') === 'true';
    if (wasOpen) {
        isChatOpen = true;
    }

    // Initialize styles and then DOM to prevent FOUC (flash of unstyled content)
    injectStyles(() => {
        // If DOM is already ready, run immediately, otherwise wait for it
        if (document.readyState === 'complete' || document.readyState === 'interactive') {
            createChatDOM();
        } else {
            document.addEventListener('DOMContentLoaded', createChatDOM);
        }
    });

    function injectStyles(callback) {
        if (document.getElementById('fms-chatbot-styles')) {
            if (callback) callback();
            return;
        }
        const link = document.createElement('link');
        link.id = 'fms-chatbot-styles';
        link.rel = 'stylesheet';
        link.href = '/FindMyScheme/css/chatbot.css';
        
        // Ensure callback runs once the link is processed by the browser
        let called = false;
        const once = () => {
            if (called) return;
            called = true;
            callback();
        };
        
        link.onload = once;
        link.onerror = once;
        
        // Fallback for some older browsers where onload on link might be finicky
        setTimeout(once, 500); 
        
        document.head.appendChild(link);
    }

    function createChatDOM() {
        if (document.getElementById('fms-chatbot-panel')) return;

        const html = `
            <button type="button" class="fms-chatbot-toggle ${isChatOpen ? 'fms-hidden' : ''}" id="fms-chatbot-toggle" title="Chat with Guidance Assistant" style="display: ${isChatOpen ? 'none' : 'flex'};">
                <span class="fms-chatbot-toggle-icon">💬</span>
                <span class="fms-chatbot-toggle-pulse"></span>
            </button>

            <div class="fms-chatbot-panel ${isChatOpen ? 'fms-open' : ''}" id="fms-chatbot-panel" style="display: ${isChatOpen ? 'flex' : 'none'};">
                <div class="fms-chatbot-header">
                    <div class="fms-chatbot-header-info">
                        <div class="fms-chatbot-avatar">🏛️</div>
                        <div class="fms-chatbot-header-text">
                            <h3>Sahayak — Scheme Advisor</h3>
                            <div class="fms-chatbot-status">
                                <span class="fms-status-dot"></span>
                                Online • Ready to Guide
                            </div>
                        </div>
                    </div>
                    <button type="button" class="fms-chatbot-close" id="fms-chatbot-close">✕</button>
                </div>

                <div class="fms-chatbot-messages" id="fms-chatbot-messages"></div>
                
                <div class="fms-chatbot-input-wrap">
                    <button type="button" class="fms-chatbot-mic" id="fms-chatbot-mic" title="Speak your question">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
                            <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                            <line x1="12" y1="19" x2="12" y2="23"></line>
                            <line x1="8" y1="23" x2="16" y2="23"></line>
                        </svg>
                    </button>
                    <input type="text" id="fms-chatbot-input" placeholder="Ask about NREGA, priority, or help..." autocomplete="off">
                    <button type="button" class="fms-chatbot-send" id="fms-chatbot-send" title="Send message">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="22" y1="2" x2="11" y2="13"></line>
                            <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                        </svg>
                    </button>
                </div>
            </div>`;

        document.body.insertAdjacentHTML('beforeend', html);
        
        bindEvents();

        // Don't restore here anymore, wait for the toggle
        if (isChatOpen) {
            restoreChatHistory();
        }
    }

    function bindEvents() {
        document.getElementById('fms-chatbot-toggle').addEventListener('click', toggleChat);
        document.getElementById('fms-chatbot-close').addEventListener('click', toggleChat);
        document.getElementById('fms-chatbot-send').addEventListener('click', handleSend);
        document.getElementById('fms-chatbot-mic').addEventListener('click', toggleSpeechRecognition);
        document.getElementById('fms-chatbot-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') handleSend();
        });

        // Delegate quick reply clicks (buttons are rendered inside chat bubbles)
        document.body.addEventListener('click', (e) => {
            const btn = e.target && e.target.closest ? e.target.closest('.fms-quick-reply') : null;
            if (!btn) return;
            const text = btn.getAttribute('data-reply') || '';
            const input = document.getElementById('fms-chatbot-input');
            input.value = text;
            handleSend();
        });
    }

    // ========== CORE LOGIC ==========

    function toggleChat() {
        isChatOpen = !isChatOpen;
        const panel = document.getElementById('fms-chatbot-panel');
        const toggle = document.getElementById('fms-chatbot-toggle');
        
        sessionStorage.setItem('fms-chatbot-open', isChatOpen);

        if (isChatOpen) {
            panel.style.display = 'flex';
            // Force browser repaint to ensure smooth transition
            void panel.offsetWidth;
            panel.classList.add('fms-open');
            toggle.classList.add('fms-hidden');
            toggle.style.display = 'none';
            
            // Load greeting only when first opened and no history exists
            const messages = document.getElementById('fms-chatbot-messages');
            if (messages.children.length === 0) {
                const history = sessionStorage.getItem('fms-chatbot-history');
                if (history && history.trim() !== '') {
                    restoreChatHistory();
                } else {
                    showGreeting();
                }
            }
        } else {
            panel.classList.remove('fms-open');
            toggle.classList.remove('fms-hidden');
            toggle.style.display = 'flex';
            
            // Wait for transition to finish before hiding from DOM
            setTimeout(() => {
                if (!isChatOpen) panel.style.display = 'none';
            }, 400);
        }
    }

    function saveChatHistory() {
        const messages = document.getElementById('fms-chatbot-messages').innerHTML;
        sessionStorage.setItem('fms-chatbot-history', messages);
    }

    function restoreChatHistory() {
        const history = sessionStorage.getItem('fms-chatbot-history');
        if (history && history.trim() !== '') {
            document.getElementById('fms-chatbot-messages').innerHTML = history;
            scrollToBottom();
        } else {
            showGreeting();
        }
    }

    async function showGreeting() {
        setProcessing(true);
        try {
            const res = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: 'hi' })
            });
            const data = await res.json();
            if (data.success) {
                addBotMessage(data.message, data.quick_replies || []);
            }
        } catch (e) {
            addBotMessage("Hello! I am your **FindMyScheme Guidance Assistant**.");
        } finally {
            setProcessing(false);
        }
    }

    async function handleSend() {
        const input = document.getElementById('fms-chatbot-input');
        const message = input.value.trim();
        if (!message || isProcessing) return;

        input.value = '';
        addUserMessage(message);
        setProcessing(true);

        try {
            const res = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message: message })
            });
            const data = await res.json();
            
            if (data.success) {
                addBotMessage(data.message, data.quick_replies || []);
            } else {
                addBotMessage("⚠️ I encountered an error. Please try again.");
            }
        } catch (e) {
            addBotMessage("⚠️ Connection error. Please check your internet.");
        } finally {
            setProcessing(false);
        }
    }

    // ========== UI HELPERS ==========

    function addUserMessage(text) {
        const container = document.getElementById('fms-chatbot-messages');
        const div = document.createElement('div');
        div.className = 'fms-msg fms-msg-user fms-msg-animate';
        div.innerHTML = `<div class="fms-msg-bubble">${escapeHTML(text)}</div>`;
        container.appendChild(div);
        scrollToBottom();
        saveChatHistory();
    }

    function addBotMessage(text, quickReplies = []) {
        removeTyping();
        const container = document.getElementById('fms-chatbot-messages');
        const div = document.createElement('div');
        div.className = 'fms-msg fms-msg-bot fms-msg-animate';
        const quickHtml = buildQuickRepliesHtml(quickReplies);
        
        // Generate a random ID for the message to handle TTS specifically for this bubble
        const msgId = 'fms-msg-' + Math.random().toString(36).substr(2, 9);
        
        div.innerHTML = `
            <div class="fms-msg-avatar">🏛️</div>
            <div class="fms-msg-bubble" id="${msgId}">
                ${formatMarkdown(text)}
                ${quickHtml}
                <button class="fms-tts-btn" title="Listen to message" onclick="speakText('${msgId}')">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                        <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.08"></path>
                    </svg>
                    <span>Listen</span>
                </button>
            </div>
        `;
        container.appendChild(div);
        scrollToBottom();
        saveChatHistory();
    }

    // TTS Functionality using Web Speech API
    window.speakText = function(msgId) {
        const bubble = document.getElementById(msgId);
        if (!bubble) return;
        
        const btn = bubble.querySelector('.fms-tts-btn');
        const textToSpeak = bubble.innerText.replace('Listen', '').trim();
        
        // If already speaking, stop it
        if (window.speechSynthesis.speaking) {
            window.speechSynthesis.cancel();
            document.querySelectorAll('.fms-tts-btn').forEach(b => {
                b.classList.remove('fms-speaking');
                b.querySelector('span').innerText = 'Listen';
            });
            return;
        }

        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        
        // Find a natural voice if possible
        const voices = window.speechSynthesis.getVoices();
        const preferredVoice = voices.find(v => v.lang.includes('en-IN')) || voices.find(v => v.lang.includes('en-US'));
        if (preferredVoice) utterance.voice = preferredVoice;

        utterance.onstart = () => {
            btn.classList.add('fms-speaking');
            btn.querySelector('span').innerText = 'Speaking...';
        };
        utterance.onend = () => {
            btn.classList.remove('fms-speaking');
            btn.querySelector('span').innerText = 'Listen';
        };
        
        window.speechSynthesis.speak(utterance);
    };

    // STT Functionality using Web Speech API (Speech Recognition)
    let recognition;
    let isListening = false;

    function toggleSpeechRecognition() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            alert("Speech recognition is not supported in this browser. Please try Chrome.");
            return;
        }

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const micBtn = document.getElementById('fms-chatbot-mic');
        const input = document.getElementById('fms-chatbot-input');

        if (isListening) {
            recognition.stop();
            return;
        }

        if (!recognition) {
            recognition = new SpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'en-IN'; // Set to Indian English, Gemini can handle if user speaks Hindi

            recognition.onstart = () => {
                isListening = true;
                micBtn.classList.add('fms-listening');
                input.placeholder = "Listening...";
            };

            recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                input.value = transcript;
                handleSend(); // Auto-send after speaking
            };

            recognition.onerror = (event) => {
                console.error("Speech recognition error:", event.error);
                stopListening();
            };

            recognition.onend = () => {
                stopListening();
            };
        }

        recognition.start();

        function stopListening() {
            isListening = false;
            micBtn.classList.remove('fms-listening');
            input.placeholder = "Ask about NREGA, priority, or help...";
        }
    }

    function buildQuickRepliesHtml(replies) {
        if (!Array.isArray(replies) || replies.length === 0) return '';
        const safe = replies
            .filter(r => typeof r === 'string' && r.trim().length > 0)
            .slice(0, 6);
        if (safe.length === 0) return '';

        const buttons = safe.map(r => {
            const label = escapeHTML(r);
            return `<button class="fms-quick-reply" type="button" data-reply="${label}">${label}</button>`;
        }).join('');

        return `<div class="fms-quick-replies">${buttons}</div>`;
    }

    function setProcessing(processing) {
        isProcessing = processing;
        const input = document.getElementById('fms-chatbot-input');
        const sendBtn = document.getElementById('fms-chatbot-send');
        
        if (processing) {
            showTyping();
            input.disabled = true;
            sendBtn.disabled = true;
        } else {
            removeTyping();
            input.disabled = false;
            sendBtn.disabled = false;
            input.focus();
        }
    }

    function showTyping() {
        if (document.getElementById('fms-typing')) return;
        const container = document.getElementById('fms-chatbot-messages');
        const div = document.createElement('div');
        div.className = 'fms-msg fms-msg-bot';
        div.id = 'fms-typing';
        div.innerHTML = `
            <div class="fms-msg-avatar">🏛️</div>
            <div class="fms-msg-bubble fms-typing-dots">
                <span></span><span></span><span></span>
            </div>
        `;
        container.appendChild(div);
        scrollToBottom();
    }

    function removeTyping() {
        const el = document.getElementById('fms-typing');
        if (el) el.remove();
    }

    function scrollToBottom() {
        const container = document.getElementById('fms-chatbot-messages');
        setTimeout(() => {
            container.scrollTop = container.scrollHeight;
        }, 50);
    }

    function formatMarkdown(text) {
        // 1. Handle headers (###)
        let html = text.replace(/^### (.*$)/gm, '<h4>$1</h4>');
        
        // 2. Handle bullet points (* or - or •)
        // Must do this BEFORE bold/italic to avoid matching bullet markers as emphasis
        html = html.replace(/^[\*•\-]\s+(.*$)/gm, '<li>$1</li>');
        
        // 3. Wrap adjacent <li> in <ul>
        html = html.replace(/(<li>.*?<\/li>)+/gs, (match) => `<ul>${match}</ul>`);

        // 4. Handle bold, italic, and links
        html = html
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" class="fms-chat-link">$1</a>');
            
        // 5. Convert remaining newlines to <br> (but not inside <ul> or <h4>)
        const parts = html.split(/(<ul>.*?<\/ul>|<h4>.*?<\/h4>)/gs);
        html = parts.map(p => {
            if (p.startsWith('<ul>') || p.startsWith('<h4>')) return p;
            return p.replace(/\n/g, '<br>');
        }).join('');
        
        return html;
    }

    function escapeHTML(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }

})();