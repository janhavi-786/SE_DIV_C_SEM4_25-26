<?php
// Get current user API
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../includes/db_config.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$userId = (int) $_SESSION['user_id'];
$result = $conn->query("SELECT id, name, email, age, income, caste, state, occupation FROM users WHERE id = $userId");

if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(['error' => 'User not found']);
    exit();
}

$user = $result->fetch_assoc();
echo json_encode(['success' => true, 'user' => $user]);
?>
