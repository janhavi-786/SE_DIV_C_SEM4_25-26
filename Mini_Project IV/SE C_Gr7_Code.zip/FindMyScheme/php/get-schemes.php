<?php
// Get User Schemes API
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../includes/db_config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$userId = (int) $_SESSION['user_id'];

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST' && isset($_POST['age'])) {
    // If data provided, update user profile first
    $age = (int) ($_POST['age'] ?? 0);
    $income = (float) ($_POST['income'] ?? 0);
    $caste = sanitize($_POST['caste'] ?? '');
    $state = sanitize($_POST['state'] ?? '');
    $occupation = sanitize($_POST['occupation'] ?? '');

    $updateSql = "UPDATE users SET age = $age, income = $income, caste = '$caste', 
                  state = '$state', occupation = '$occupation' WHERE id = $userId";
    $conn->query($updateSql);
} else {
    // If no data provided (e.g. GET or empty POST), fetch current user data
    $userResult = $conn->query("SELECT age, income, caste, state, occupation FROM users WHERE id = $userId");
    if ($userResult->num_rows > 0) {
        $user = $userResult->fetch_assoc();
        $age = (int) ($user['age'] ?? 0);
        $income = (float) ($user['income'] ?? 0);
        $caste = $user['caste'] ?? '';
        $state = $user['state'] ?? '';
        $occupation = $user['occupation'] ?? '';
    } else {
        // User not found?? Should handle this, but for now defaults
        $age = 0; $income = 0; $caste = ''; $state = ''; $occupation = '';
    }
}
// Get matching schemes
$schemes = [];

// Prepare search logging
$searchParams = json_encode([
    'age' => $age,
    'income' => $income,
    'caste' => $caste,
    'state' => $state,
    'occupation' => $occupation
]);

// Initial log to get ID
$conn->query("INSERT INTO search_history (user_id, search_params) VALUES ($userId, '$searchParams')");
$searchId = $conn->insert_id;

$schemeQuery = "SELECT s.*, er.age_min, er.age_max, er.income_max, 
                er.caste_category, er.states, er.occupations 
                FROM schemes s
                LEFT JOIN eligibility_rules er ON s.id = er.scheme_id
                WHERE s.status = 'active'";
    
$result = $conn->query($schemeQuery);

    while ($scheme = $result->fetch_assoc()) {
        $eligible = true;
        $confidence = 'high';
        $reasons = [];
        $mismatch = 0;

        // Age check with detailed reasons
        if ($scheme['age_min'] !== null || $scheme['age_max'] !== null) {
            $ageMin = $scheme['age_min'] ?? 0;
            $ageMax = $scheme['age_max'] ?? 120;
            if ($age >= $ageMin && $age <= $ageMax) {
                if ($ageMin > 0 || $ageMax < 120) {
                    $reasons[] = "✓ Your age ($age years) falls within the required range ($ageMin-$ageMax years)";
                } else {
                    $reasons[] = "✓ Eligible for your age group";
                }
            } else {
                $eligible = false;
                $mismatch++;
            }
        }

        // Income check with detailed reasons
        if ($scheme['income_max'] !== null) {
            if ($income <= $scheme['income_max']) {
                $reasons[] = "✓ Your annual income (₹" . number_format($income) . ") is below the maximum limit (₹" . number_format($scheme['income_max']) . ")";
            } else {
                $eligible = false;
                $mismatch++;
            }
        }

        // State check with detailed reasons
        if ($scheme['states'] !== null && !empty($state)) {
            $states = json_decode($scheme['states'], true);
            if (is_array($states) && in_array($state, $states)) {
                $reasons[] = "✓ This scheme is available in your state ($state)";
            } elseif (is_array($states)) {
                $eligible = false;
                $mismatch++;
            }
        } elseif ($scheme['states'] === null && !empty($state)) {
            $reasons[] = "✓ This scheme is available nationwide, including your state ($state)";
        }

        // Caste check with detailed reasons
        if ($scheme['caste_category'] !== null) {
            if (empty($caste)) {
                // No caste provided, but scheme has caste requirement
                if ($scheme['caste_category'] === 'General') {
                    $reasons[] = "✓ Open to all categories (General)";
                } else {
                    // Can't determine eligibility without caste info
                    $confidence = 'medium';
                }
            } elseif ($scheme['caste_category'] === $caste || $scheme['caste_category'] === 'General') {
                $reasons[] = "✓ Your caste category ($caste) qualifies for this scheme";
            } else {
                $eligible = false;
                $mismatch++;
            }
        }

        // Occupation check with detailed reasons
        if ($scheme['occupations'] !== null && !empty($occupation)) {
            $occupations = json_decode($scheme['occupations'], true);
            if (is_array($occupations) && in_array($occupation, $occupations)) {
                $reasons[] = "✓ Your occupation ($occupation) is eligible for this scheme";
            } elseif (is_array($occupations)) {
                $eligible = false;
                $mismatch++;
            }
        } elseif ($scheme['occupations'] === null && !empty($occupation)) {
            $reasons[] = "✓ This scheme is open to all occupations, including yours ($occupation)";
        }

        // Calculate confidence based on how many criteria match
        $totalCriteria = 0;
        $matchedCriteria = 0;
        
        if ($scheme['age_min'] !== null || $scheme['age_max'] !== null) {
            $totalCriteria++;
            if ($age >= ($scheme['age_min'] ?? 0) && $age <= ($scheme['age_max'] ?? 120)) {
                $matchedCriteria++;
            }
        }
        
        if ($scheme['income_max'] !== null) {
            $totalCriteria++;
            if ($income <= $scheme['income_max']) {
                $matchedCriteria++;
            }
        }
        
        if ($scheme['caste_category'] !== null) {
            $totalCriteria++;
            if (empty($caste) || $scheme['caste_category'] === $caste || $scheme['caste_category'] === 'General') {
                $matchedCriteria++;
            }
        }
        
        if ($scheme['states'] !== null) {
            $totalCriteria++;
            $states = json_decode($scheme['states'], true);
            if (is_array($states) && (empty($state) || in_array($state, $states))) {
                $matchedCriteria++;
            }
        }
        
        if ($scheme['occupations'] !== null) {
            $totalCriteria++;
            $occupations = json_decode($scheme['occupations'], true);
            if (is_array($occupations) && (empty($occupation) || in_array($occupation, $occupations))) {
                $matchedCriteria++;
            }
        }
        
        // Calculate confidence based on the number of 'Why am I eligible' statements (reasons)
        $reasonCount = count($reasons);
        if ($reasonCount > 2) {
            $confidence = 'high';
        } elseif ($reasonCount == 2) {
            $confidence = 'medium';
        } elseif ($reasonCount == 1) {
            $confidence = 'low';
        } else {
            // Default for schemes with 0 specific matched reasons (usually open to everyone)
            $confidence = 'low';
        }

        if ($eligible) {
            $schemes[] = [
                'id' => $scheme['id'],
                'name' => $scheme['name'],
                'description' => $scheme['description'],
                'benefits' => $scheme['benefits'],
                'category' => $scheme['category'],
                'apply_url' => $scheme['apply_url'] ?? null,
                'required_documents' => $scheme['required_documents'] ?? null,
                'confidence' => $confidence,
                'reasons' => $reasons
            ];

            // Log the application
            $reasonsJson = $conn->real_escape_string(json_encode(['reasons' => $reasons]));
            $conn->query("INSERT INTO user_scheme_applications 
                         (user_id, scheme_id, confidence_level, eligibility_details, application_status, search_id)
                         VALUES ($userId, {$scheme['id']}, '$confidence', '$reasonsJson', 'eligible', $searchId)");
        }
    }

    // Update results count
    $resultsCount = count($schemes);
    $conn->query("UPDATE search_history SET results_count = $resultsCount WHERE id = $searchId");

    /**
     * Store eligible schemes in session for chatbot recommendations.
     * Note: This does NOT re-search schemes; it simply saves the already computed eligible list.
     */
    $_SESSION['eligible_schemes'] = array_map(function ($s) {
        $cat = strtolower(trim($s['category'] ?? ''));

        // Normalize to required chatbot categories
        $normalized = 'financial';
        if (strpos($cat, 'health') !== false) {
            $normalized = 'health';
        } elseif (strpos($cat, 'educat') !== false || strpos($cat, 'scholar') !== false) {
            $normalized = 'education';
        } elseif (strpos($cat, 'employ') !== false) {
            $normalized = 'employment';
        } elseif (strpos($cat, 'agri') !== false || strpos($cat, 'farmer') !== false) {
            $normalized = 'agriculture';
        } elseif (strpos($cat, 'finance') !== false || strpos($cat, 'social') !== false || strpos($cat, 'pension') !== false) {
            $normalized = 'financial';
        }

        return [
            'name' => $s['name'] ?? '',
            'category' => $normalized,
            'benefits' => $s['benefits'] ?? ''
        ];
    }, $schemes);

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'schemes' => $schemes,
        'totalSchemes' => count($schemes)
    ]);
// End of script
?>
