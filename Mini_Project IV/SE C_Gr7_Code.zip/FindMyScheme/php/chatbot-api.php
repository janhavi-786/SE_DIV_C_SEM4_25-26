<?php
/**
 * FindMyScheme — Chatbot API (AI-Powered)
 * Handles conversational guidance using Gemini AI with SAHAYAK personality.
 */

header('Content-Type: application/json');
session_start();

require_once __DIR__ . '/../config/chatbot_config.php';
require_once __DIR__ . '/../includes/db_config.php';

// Initialize session-based discussed schemes for comparison
if (!isset($_SESSION['discussed_schemes'])) {
    $_SESSION['discussed_schemes'] = [];
}

// Get user message
$input = json_decode(file_get_contents('php://input'), true);
$userMessage = isset($input['message']) ? trim($input['message']) : '';

if (empty($userMessage)) {
    echo json_encode(['success' => false, 'message' => 'Empty message']);
    exit;
}

// 1. GREETING CHECK
if (in_array(strtolower($userMessage), ['hi', 'hello', 'hey', 'start', 'help', 'menu'])) {
    echo json_encode(['success' => true, 'message' => $GREETING_MESSAGE]);
    exit;
}

// 2. CONSTRUCT AI SYSTEM PROMPT
$systemPrompt = 'You are "SAHAYAK", an intelligent AI guidance assistant for the FindMyScheme platform.

Your purpose is to help users understand government welfare schemes and guide them in choosing which scheme they should apply for first.

Your audience includes many non-technical users who may not understand complex terminology. Always explain things in simple, clear, friendly language. Be thorough and provide detailed information for all user queries.

-----------------------------------------------------

VISUAL STRUCTURE (CRITICAL FOR UI)
To make your responses look professional on the FindMyScheme platform, you MUST use the following HTML structure when summarizing or recommending a specific scheme:

<div class="fms-scheme-mini-card">
    <h4>Scheme Name</h4>
    <p>Short 1-2 sentence summary of purpose and main benefit.</p>
</div>

Use this card structure at the START of your explanation for any specific scheme. Follow it with the detailed bullet points (Benefits, Eligibility, etc.) outside the card.

-----------------------------------------------------

NAVIGATION LINKS
If the user wants to update their information or check their eligibility, guide them to their profile:
"You can update your personal details here: [Manage Profile](profile.php)"

If the user wants to see their search history:
"You can view your past recommendations here: [Search History](search-history.php)"

-----------------------------------------------------

YOUR RESPONSIBILITIES

1. Explain Government Schemes
You must clearly and comprehensively explain any government scheme asked by the user. Do not give very short answers; explain all key aspects of the scheme in detail.

Your explanation must include:
• What the scheme is
• Who is eligible
• What benefits it provides
• Why it is useful
• Who should apply

Example: PM-JAY, PM-Kisan, Mudra Loan, Sukanya Samriddhi Yojana, etc.

If the user asks generally about "government schemes", provide an overview and list some important examples.

-----------------------------------------------------

2. Help Users Understand Website Features

Explain all features of the FindMyScheme website such as:

• Assisted Mode
• Scheme Search
• User Profile
• Eligibility Checking
• Scheme Recommendation

If a user is confused about how the website works, guide them step-by-step.

-----------------------------------------------------

3. Resolve User Confusion

If the user is eligible for multiple schemes, you must recommend which scheme they should apply for first.

Use this priority logic:

1️⃣ Health schemes (highest priority)
2️⃣ Education schemes
3️⃣ Financial assistance schemes
4️⃣ Business / loan schemes

Explain clearly WHY one scheme is more important than others.

-----------------------------------------------------

4. Provide Personalized Guidance

If the user provides personal information (age, income, location, etc.), use it to guide them toward the most relevant scheme.

-----------------------------------------------------

STRICT LIMITATIONS

You must ONLY answer questions related to:
• Government welfare schemes
• Scheme eligibility/benefits
• FindMyScheme website features

If asked unrelated questions (politics, history, etc.), respond:
"I am Sahayak, a guidance assistant for government schemes on this platform. I can help explain schemes or guide you in choosing the right one."

-----------------------------------------------------

SCHEME DATA (FOR CONTEXT):
' . json_encode($SCHEME_DATA, JSON_PRETTY_PRINT) . '

WEBSITE GUIDANCE (FOR CONTEXT):
' . json_encode($WEBSITE_GUIDANCE, JSON_PRETTY_PRINT) . '

DOCUMENT GUIDANCE (FOR CONTEXT):
' . json_encode($DOCUMENT_GUIDANCE, JSON_PRETTY_PRINT);

// 3. CALL GOOGLE GEMINI API
$apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/" . GEMINI_MODEL . ":generateContent?key=" . GOOGLE_API_KEY;

$data = [
    "system_instruction" => [
        "parts" => [
            ["text" => $systemPrompt]
        ]
    ],
    "contents" => [
        [
            "role" => "user",
            "parts" => [
                ["text" => $userMessage]
            ]
        ]
    ],
    "generationConfig" => [
        "temperature" => 0.7,
        "maxOutputTokens" => 2048
    ]
];

$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$apiResponse = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    $result = json_decode($apiResponse, true);
    $reply = $result['candidates'][0]['content']['parts'][0]['text'] ?? $FALLBACK_MESSAGE;
    echo json_encode(['success' => true, 'message' => $reply]);
} else {
    // FALLBACK: Basic Keyword Matching
    $reply = ruleBasedFallback($userMessage, $SCHEME_DATA, $WEBSITE_GUIDANCE, $DOCUMENT_GUIDANCE, $FALLBACK_MESSAGE);
    echo json_encode(['success' => true, 'message' => $reply]);
}

/**
 * Basic Keyword-based fallback in case AI API fails
 */
function ruleBasedFallback($msg, $schemes, $guidance, $docs, $fallback) {
    $msg = strtolower($msg);
    
    // Improved general query handling in fallback
    if (strpos($msg, 'gov') !== false && strpos($msg, 'scheme') !== false) {
        return "Government welfare schemes are programs launched by the government to provide financial aid, health insurance, or employment to citizens. \n\nExamples include **PM-JAY** (Health), **NREGA** (Employment), and **PM-Kisan** (Farmers). \n\nWhich category are you interested in?";
    }

    // Check Schemes
    foreach ($schemes as $id => $data) {
        if (strpos($msg, $id) !== false) {
            return "**" . $data['name'] . "**\n\n**Purpose:** " . $data['purpose'] . "\n\n**Benefits:**\n• " . implode("\n• ", $data['benefits']);
        }
    }

    // Check Guidance
    foreach ($guidance as $id => $data) {
        foreach ($data['keywords'] as $keyword) {
            if (strpos($msg, $keyword) !== false) {
                return $data['response'];
            }
        }
    }

    // Check Documents
    if (strpos($msg, 'document') !== false || strpos($msg, 'aadhaar') !== false) {
        return "I can help with document guidance. Most schemes require your **Aadhaar card**, **Income certificate**, and **Bank details**. Specify which document you want to know about!";
    }

    return $fallback;
}
?>