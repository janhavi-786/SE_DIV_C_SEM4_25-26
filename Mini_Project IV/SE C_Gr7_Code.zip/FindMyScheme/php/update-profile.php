<?php
// Update user profile API
header('Content-Type: application/json');
session_start();

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$userId = (int)$_SESSION['user_id'];

// Initialize update array
$updates = [];
$types = "";
$params = [];

// Name (only validate if provided)
if (isset($_POST['name'])) {
    $name = trim($_POST['name']);
    if ($name === '' || mb_strlen($name) < 2) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Name is required (min 2 characters).']);
        exit();
    }
    $updates[] = "name = ?";
    $types .= "s";
    $params[] = $name;
}

// Age
if (isset($_POST['age'])) {
    $age = $_POST['age'] !== '' ? (int)$_POST['age'] : null;
    if ($age !== null && ($age < 1 || $age > 120)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Age must be between 1 and 120.']);
        exit();
    }
    $updates[] = "age = ?";
    $types .= "i";
    $params[] = $age;
}

// Income
if (isset($_POST['income'])) {
    $income = $_POST['income'] !== '' ? (float)$_POST['income'] : null;
    if ($income !== null && $income < 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Income must be 0 or more.']);
        exit();
    }
    $updates[] = "income = ?";
    $types .= "d";
    $params[] = $income;
}

// Caste
if (isset($_POST['caste'])) {
    $caste = trim($_POST['caste']);
    $updates[] = "caste = ?";
    $types .= "s";
    $params[] = $caste === '' ? null : $caste;
}

// State
if (isset($_POST['state'])) {
    $state = trim($_POST['state']);
    $updates[] = "state = ?";
    $types .= "s";
    $params[] = $state === '' ? null : $state;
}

// Occupation
if (isset($_POST['occupation'])) {
    $occupation = trim($_POST['occupation']);
    $updates[] = "occupation = ?";
    $types .= "s";
    $params[] = $occupation === '' ? null : $occupation;
}

if (empty($updates)) {
    echo json_encode(['success' => true, 'message' => 'No changes to update.']);
    exit();
}

$sql = "UPDATE users SET " . implode(", ", $updates) . " WHERE id = ?";
$types .= "i";
$params[] = $userId;

$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    exit();
}

$stmt->bind_param($types, ...$params);

if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to update profile: ' . $stmt->error]);
    exit();
}

logActivity('profile_updated', $userId, 'User updated profile');

echo json_encode(['success' => true, 'message' => 'Profile updated successfully.']);

