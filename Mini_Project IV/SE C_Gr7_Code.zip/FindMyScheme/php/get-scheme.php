<?php
// Get single scheme details API
header('Content-Type: application/json');
session_start();

require_once __DIR__ . '/../includes/db_config.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$schemeId = (int)($_GET['id'] ?? 0);
if ($schemeId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid scheme id']);
    exit();
}

$schemeQuery = "
    SELECT
        s.id, s.name, s.description, s.benefits, s.category, s.status,
        s.apply_url, s.required_documents,
        er.age_min, er.age_max, er.income_max, er.caste_category, er.states, er.occupations, er.other_criteria
    FROM schemes s
    LEFT JOIN eligibility_rules er ON s.id = er.scheme_id
    WHERE s.id = $schemeId
    LIMIT 1
";

$result = $conn->query($schemeQuery);
if (!$result || $result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Scheme not found']);
    exit();
}

$scheme = $result->fetch_assoc();

echo json_encode([
    'success' => true,
    'scheme' => $scheme
]);

