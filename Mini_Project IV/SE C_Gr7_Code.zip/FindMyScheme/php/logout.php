<?php
// User Logout
session_start();

$_SESSION = array();

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

// Clear Chatbot session storage via a small script before redirecting
?>
<!DOCTYPE html>
<html>
<head>
    <title>Logging out...</title>
    <script>
        // Clear all chatbot related data from sessionStorage
        sessionStorage.removeItem('fms-chatbot-open');
        sessionStorage.removeItem('fms-chatbot-history');
        // Redirect to index
        window.location.href = "/FindMyScheme/index.php";
    </script>
</head>
<body>
    <p>Logging out, please wait...</p>
</body>
</html>
<?php
exit();
?>