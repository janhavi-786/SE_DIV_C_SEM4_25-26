<?php
// Eligibility Rules Page
session_start();
require_once __DIR__ . '/../includes/auth.php';

if (!isAdminLoggedIn()) {
    header("Location: login.html");
    exit();
}

$success_message = '';
$error_message = '';

// Get schemes
$schemesResult = $conn->query("SELECT id, name FROM schemes ORDER BY name");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $scheme_id = (int) $_POST['scheme_id'];
    $age_min = isset($_POST['age_min']) && !empty($_POST['age_min']) ? (int) $_POST['age_min'] : null;
    $age_max = isset($_POST['age_max']) && !empty($_POST['age_max']) ? (int) $_POST['age_max'] : null;
    $income_max = isset($_POST['income_max']) && !empty($_POST['income_max']) ? (float) $_POST['income_max'] : null;
    $caste_category = sanitize($_POST['caste_category'] ?? '');
    $other_criteria = sanitize($_POST['other_criteria'] ?? '');

    // Delete existing rules for this scheme
    $conn->query("DELETE FROM eligibility_rules WHERE scheme_id = $scheme_id");

    // Insert new rule
    $ageMin = $age_min ? $age_min : 'NULL';
    $ageMax = $age_max ? $age_max : 'NULL';
    $incomeMax = $income_max ? $income_max : 'NULL';
    $casteCategory = $caste_category ? "'$caste_category'" : 'NULL';

    $sql = "INSERT INTO eligibility_rules (scheme_id, age_min, age_max, income_max, caste_category, other_criteria) 
            VALUES ($scheme_id, $ageMin, $ageMax, $incomeMax, $casteCategory, '$other_criteria')";
    
    if ($conn->query($sql)) {
        $success_message = 'Eligibility rules updated successfully!';
    } else {
        $error_message = 'Error updating rules: ' . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eligibility Rules - FindMyScheme Admin</title>
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <!-- Admin Header -->
    <div class="admin-header">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center;">
                    <img src="../assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px;">
                    <h1 style="margin: 0;"><span style="color: #FF9933;">FindMyScheme</span> <span style="color: white;">Admin</span></h1>
                </div>
                <a href="logout.php" style="color: white; font-weight: 600;">Logout</a>
            </div>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container" style="padding: 30px 15px;">
        <div class="admin-container">
            <!-- Sidebar Navigation -->
            <div class="admin-sidebar">
                <ul>
                    <li><a href="dashboard.php">📊 Dashboard</a></li>
                    <li><a href="manage-schemes.php">📚 Manage Schemes</a></li>
                    <li><a href="eligibility-rules.php" class="active">📋 Eligibility Rules</a></li>
                    <li><a href="view-users.php">👥 View Users</a></li>
                    <li><a href="view-applications.php">📑 View Applications</a></li>
                    <li><a href="activity-logs.php">📜 Activity Logs</a></li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="admin-content">
                <h2 class="admin-title">📋 Manage Eligibility Rules</h2>

                <?php if ($success_message): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php endif; ?>

                <?php if ($error_message): ?>
                    <div class="alert alert-error"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <form method="POST" style="max-width: 600px; background-color: #f5f5f5; padding: 20px; border-radius: 8px; margin-bottom: 30px;">
                    <div class="form-group">
                        <label for="scheme_id">Select Scheme *</label>
                        <select id="scheme_id" name="scheme_id" required>
                            <option value="">Choose a scheme</option>
                            <?php 
                            $schemesResult->data_seek(0);
                            while ($scheme = $schemesResult->fetch_assoc()): 
                            ?>
                            <option value="<?php echo $scheme['id']; ?>"><?php echo htmlspecialchars($scheme['name']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="age_min">Minimum Age</label>
                        <input type="number" id="age_min" name="age_min" min="1" max="120" placeholder="e.g., 18">
                    </div>

                    <div class="form-group">
                        <label for="age_max">Maximum Age</label>
                        <input type="number" id="age_max" name="age_max" min="1" max="120" placeholder="e.g., 65">
                    </div>

                    <div class="form-group">
                        <label for="income_max">Maximum Income (₹)</label>
                        <input type="number" id="income_max" name="income_max" min="0" step="1000" placeholder="e.g., 500000">
                    </div>

                    <div class="form-group">
                        <label for="caste_category">Caste Category</label>
                        <select id="caste_category" name="caste_category">
                            <option value="">Any Category</option>
                            <option value="General">General</option>
                            <option value="OBC">OBC</option>
                            <option value="SC">SC</option>
                            <option value="ST">ST</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="other_criteria">Other Criteria</label>
                        <textarea id="other_criteria" name="other_criteria" rows="3" placeholder="e.g., BPL families, Rural residents"></textarea>
                    </div>

                    <input type="hidden" name="action" value="update">
                    <button type="submit" class="btn btn-primary">Update Rules</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
