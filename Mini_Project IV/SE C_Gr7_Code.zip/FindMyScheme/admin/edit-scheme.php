<?php
// Edit Scheme Page
session_start();
require_once __DIR__ . '/../includes/auth.php';

if (!isAdminLoggedIn()) {
    header("Location: login.html");
    exit();
}

$scheme_id = (int) ($_GET['id'] ?? 0);

if ($scheme_id === 0) {
    header("Location: manage-schemes.php");
    exit();
}

// Get scheme data
$schemeResult = $conn->query("SELECT * FROM schemes WHERE id = $scheme_id");
if ($schemeResult->num_rows === 0) {
    header("Location: manage-schemes.php");
    exit();
}

$scheme = $schemeResult->fetch_assoc();
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $benefits = sanitize($_POST['benefits'] ?? '');
    $category = sanitize($_POST['category'] ?? '');
    $status = sanitize($_POST['status'] ?? '');
    $apply_url = sanitize($_POST['apply_url'] ?? '');
    $application_process = sanitize($_POST['application_process'] ?? '');
    $required_documents = sanitize($_POST['required_documents'] ?? '');

    if (empty($name) || empty($description)) {
        $error_message = 'Scheme name and description are required.';
    } else {
        $sql = "UPDATE schemes SET name = '$name', description = '$description', 
                benefits = '$benefits', category = '$category',
                apply_url = '$apply_url', application_process = '$application_process',
                required_documents = '$required_documents',
                status = '$status' 
                WHERE id = $scheme_id";
        
        if ($conn->query($sql)) {
            $success_message = 'Scheme updated successfully!';
            $scheme = ['id' => $scheme_id, 'name' => $name, 'description' => $description, 
                      'benefits' => $benefits, 'category' => $category,
                      'apply_url' => $apply_url, 'application_process' => $application_process,
                      'required_documents' => $required_documents,
                      'status' => $status];
        } else {
            $error_message = 'Error updating scheme: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Scheme - FindMyScheme Admin</title>
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <!-- Admin Header -->
    <div class="admin-header">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center;">
                    <img src="../assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px;">
                    <h1 style="margin: 0;"><span style="color: #FF9933;">FindMyScheme</span> <span style="color: white;">Admin</span></h1>
                </div>
                <a href="logout.php" style="color: white; font-weight: 600;">Logout</a>
            </div>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container" style="padding: 30px 15px;">
        <div class="admin-container">
            <!-- Sidebar Navigation -->
            <div class="admin-sidebar">
                <ul>
                    <li><a href="dashboard.php">📊 Dashboard</a></li>
                    <li><a href="manage-schemes.php" class="active">📚 Manage Schemes</a></li>
                    <li><a href="eligibility-rules.php">📋 Eligibility Rules</a></li>
                    <li><a href="view-users.php">👥 View Users</a></li>
                    <li><a href="view-applications.php">📑 View Applications</a></li>
                    <li><a href="activity-logs.php">📜 Activity Logs</a></li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="admin-content">
                <h2 class="admin-title">✏️ Edit Scheme</h2>

                <?php if ($success_message): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php endif; ?>

                <?php if ($error_message): ?>
                    <div class="alert alert-error"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <form method="POST" style="max-width: 600px;">
                    <div class="form-group">
                        <label for="name">Scheme Name *</label>
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($scheme['name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="category">Category *</label>
                        <select id="category" name="category" required>
                            <option value="">Select Category</option>
                            <option value="Healthcare" <?php echo $scheme['category'] === 'Healthcare' ? 'selected' : ''; ?>>Healthcare</option>
                            <option value="Education" <?php echo $scheme['category'] === 'Education' ? 'selected' : ''; ?>>Education</option>
                            <option value="Employment" <?php echo $scheme['category'] === 'Employment' ? 'selected' : ''; ?>>Employment</option>
                            <option value="Finance" <?php echo $scheme['category'] === 'Finance' ? 'selected' : ''; ?>>Finance</option>
                            <option value="Social Security" <?php echo $scheme['category'] === 'Social Security' ? 'selected' : ''; ?>>Social Security</option>
                            <option value="Agriculture" <?php echo $scheme['category'] === 'Agriculture' ? 'selected' : ''; ?>>Agriculture</option>
                            <option value="Energy" <?php echo $scheme['category'] === 'Energy' ? 'selected' : ''; ?>>Energy</option>
                            <option value="Infrastructure" <?php echo $scheme['category'] === 'Infrastructure' ? 'selected' : ''; ?>>Infrastructure</option>
                            <option value="Other" <?php echo $scheme['category'] === 'Other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="status">Status *</label>
                        <select id="status" name="status" required>
                            <option value="active" <?php echo $scheme['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $scheme['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="description">Description *</label>
                        <textarea id="description" name="description" rows="4" required><?php echo htmlspecialchars($scheme['description']); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="benefits">Benefits</label>
                        <textarea id="benefits" name="benefits" rows="4"><?php echo htmlspecialchars($scheme['benefits']); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="application_process">Application Process (optional)</label>
                        <textarea id="application_process" name="application_process" rows="4" placeholder="Step-by-step guide on how to apply"><?php echo htmlspecialchars($scheme['application_process'] ?? ''); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="apply_url">Apply Link (optional)</label>
                        <input type="url" id="apply_url" name="apply_url" value="<?php echo htmlspecialchars($scheme['apply_url'] ?? ''); ?>" placeholder="https://...">
                    </div>

                    <div class="form-group">
                        <label for="required_documents">Required Documents (optional)</label>
                        <textarea id="required_documents" name="required_documents" rows="5" placeholder="One document per line"><?php echo htmlspecialchars($scheme['required_documents'] ?? ''); ?></textarea>
                    </div>

                    <div style="display: flex; gap: 10px;">
                        <button type="submit" class="btn btn-primary">Update Scheme</button>
                        <a href="manage-schemes.php" class="btn btn-outline">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
