<?php
// View Users Page
session_start();
require_once __DIR__ . '/../includes/auth.php';

if (!isAdminLoggedIn()) {
    header("Location: login.html");
    exit();
}

// Get all users
$usersResult = $conn->query("SELECT id, name, email, state, created_at FROM users ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Users - FindMyScheme Admin</title>
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <!-- Admin Header -->
    <div class="admin-header">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center;">
                    <img src="../assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px;">
                    <h1 style="margin: 0;"><span style="color: #FF9933;">FindMyScheme</span> <span style="color: white;">Admin</span></h1>
                </div>
                <a href="logout.php" style="color: white; font-weight: 600;">Logout</a>
            </div>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container" style="padding: 30px 15px;">
        <div class="admin-container">
            <!-- Sidebar Navigation -->
            <div class="admin-sidebar">
                <ul>
                    <li><a href="dashboard.php">📊 Dashboard</a></li>
                    <li><a href="manage-schemes.php">📚 Manage Schemes</a></li>
                    <li><a href="eligibility-rules.php">📋 Eligibility Rules</a></li>
                    <li><a href="view-users.php" class="active">👥 View Users</a></li>
                    <li><a href="view-applications.php">📑 View Applications</a></li>
                    <li><a href="activity-logs.php">📜 Activity Logs</a></li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="admin-content">
                <h2 class="admin-title">👥 Registered Users</h2>

                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>User Name</th>
                            <th>Email</th>
                            <th>State</th>
                            <th>Registered Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = $usersResult->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['name']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td><?php echo htmlspecialchars($user['state']); ?></td>
                            <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
