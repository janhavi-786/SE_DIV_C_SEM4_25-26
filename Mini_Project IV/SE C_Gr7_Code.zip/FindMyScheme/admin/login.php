<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - FindMyScheme</title>
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="../assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme Admin
                    <div class="logo-subtitle">Administration Panel</div>
                </div>
            </div>
        </div>
    </header>

    <!-- Login Container -->
    <div class="auth-container">
        <div class="auth-header">
            <div class="auth-logo">🔐</div>
            <h2 class="auth-title">Admin Login</h2>
        </div>

        <form id="adminLoginForm">
            <div class="form-group">
                <label for="username">Admin Username *</label>
                <input type="text" id="username" name="username" placeholder="Enter admin username" required>
                <div class="form-error" id="usernameError"></div>
            </div>

            <div class="form-group">
                <label for="password">Password *</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
                <div class="form-error" id="passwordError"></div>
            </div>

            <div id="errorMessage" class="alert alert-error" style="display: none; margin-bottom: 15px;"></div>

            <button type="submit" class="btn btn-primary btn-block" style="margin-top: 20px; padding: 12px;">Login</button>
        </form>

        <div class="auth-footer">
            <p><a href="../index.php" style="color: var(--navy-blue);">← Back to FindMyScheme</a></p>
            <p style="font-size: 12px; margin-top: 10px; color: #666;">
                Default credentials: admin / admin123
            </p>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>

    <script src="../js/validation.js"></script>
    <script>
        document.getElementById('adminLoginForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;

            try {
                const formData = new URLSearchParams();
                formData.append('username', username);
                formData.append('password', password);

                const response = await fetch('login-api.php', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();

                if (data.success) {
                    window.location.href = data.redirect;
                } else {
                    document.getElementById('errorMessage').style.display = 'block';
                    document.getElementById('errorMessage').textContent = data.message;
                }
            } catch (error) {
                console.error('Login error:', error);
                document.getElementById('errorMessage').style.display = 'block';
                document.getElementById('errorMessage').textContent = 'An error occurred. Please try again.';
            }
        });
    </script>
</body>
</html>
