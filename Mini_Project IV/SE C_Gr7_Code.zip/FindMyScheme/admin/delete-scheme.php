<?php
// Delete Scheme Handler
session_start();
require_once __DIR__ . '/../includes/auth.php';

if (!isAdminLoggedIn()) {
    header("Location: login.html");
    exit();
}

$scheme_id = (int) ($_GET['id'] ?? 0);

if ($scheme_id > 0) {
    $conn->query("DELETE FROM schemes WHERE id = $scheme_id");
    logActivity($_SESSION['admin_id'], null, "Admin deleted scheme with ID: $scheme_id");
}

header("Location: manage-schemes.php");
exit();
?>
