<?php
// View Applications (Matches) Page
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_config.php';

if (!isAdminLoggedIn()) {
    header("Location: login.html");
    exit();
}

// Get all applications with user and scheme details
$query = "
    SELECT 
        usa.id,
        usa.search_id,
        usa.confidence_level,
        usa.applied_at,
        u.name as user_name,
        u.email as user_email,
        s.name as scheme_name
    FROM user_scheme_applications usa
    JOIN users u ON usa.user_id = u.id
    JOIN schemes s ON usa.scheme_id = s.id
    ORDER BY usa.applied_at DESC
";
$applicationsResult = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Applications - FindMyScheme Admin</title>
    <link rel="stylesheet" href="../css/main.css">
    <style>
        .confidence-tag {
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
        }
        .confidence-high { background: #e8f5e9; color: #2e7d32; }
        .confidence-medium { background: #fff3e0; color: #f57c00; }
        .confidence-low { background: #ffebee; color: #d32f2f; }
        
        .search-id-badge {
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
            color: #666;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <!-- Admin Header -->
    <div class="admin-header">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center;">
                    <img src="../assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px;">
                    <h1 style="margin: 0;"><span style="color: #FF9933;">FindMyScheme</span> <span style="color: white;">Admin</span></h1>
                </div>
                <div style="display: flex; gap: 20px; align-items: center;">
                    <a href="logout.php" style="color: white; font-weight: 600;">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container" style="padding: 30px 15px;">
        <div class="admin-container">
            <!-- Sidebar Navigation -->
            <div class="admin-sidebar">
                <ul>
                    <li><a href="dashboard.php">📊 Dashboard</a></li>
                    <li><a href="manage-schemes.php">📚 Manage Schemes</a></li>
                    <li><a href="eligibility-rules.php">📋 Eligibility Rules</a></li>
                    <li><a href="view-users.php">👥 View Users</a></li>
                    <li><a href="view-applications.php" class="active">📑 View Applications</a></li>
                    <li><a href="activity-logs.php">📜 Activity Logs</a></li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="admin-content">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                    <h2 class="admin-title" style="margin: 0;">📑 User Applications (Matches)</h2>
                </div>

                <p style="color: #666; margin-bottom: 20px;">
                    This list shows all instances where a user was found eligible for a scheme.
                </p>

                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Search ID</th>
                            <th>User</th>
                            <th>Scheme</th>
                            <th>Confidence</th>
                            <th>Matched On</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($applicationsResult && $applicationsResult->num_rows > 0): ?>
                            <?php while ($app = $applicationsResult->fetch_assoc()): ?>
                            <tr>
                                <td><span class="search-id-badge">#<?php echo $app['search_id'] ?: 'N/A'; ?></span></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($app['user_name']); ?></strong><br>
                                    <span style="font-size: 11px; color: #888;"><?php echo htmlspecialchars($app['user_email']); ?></span>
                                </td>
                                <td><?php echo htmlspecialchars($app['scheme_name']); ?></td>
                                <td>
                                    <span class="confidence-tag confidence-<?php echo $app['confidence_level']; ?>">
                                        <?php echo ucfirst($app['confidence_level']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y H:i', strtotime($app['applied_at'])); ?></td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" style="text-align: center; padding: 40px; color: #999;">
                                    No applications found yet.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
