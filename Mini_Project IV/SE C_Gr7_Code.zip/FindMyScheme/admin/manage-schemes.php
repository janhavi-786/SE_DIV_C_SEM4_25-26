<?php
// Manage Schemes Page
session_start();
require_once __DIR__ . '/../includes/auth.php';

if (!isAdminLoggedIn()) {
    header("Location: login.html");
    exit();
}

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $scheme_id = (int) $_POST['scheme_id'];
    $conn->query("DELETE FROM schemes WHERE id = $scheme_id");
    header("Location: manage-schemes.php");
    exit();
}

// Get all schemes
$schemesResult = $conn->query("SELECT id, name, description, category, status, created_at FROM schemes ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Schemes - FindMyScheme Admin</title>
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <!-- Admin Header -->
    <div class="admin-header">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center;">
                    <img src="../assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px;">
                    <h1 style="margin: 0;"><span style="color: #FF9933;">FindMyScheme</span> <span style="color: white;">Admin</span></h1>
                </div>
                <div style="display: flex; gap: 20px; align-items: center;">
                    <a href="dashboard.php" style="color: white;">Dashboard</a>
                    <a href="logout.php" style="color: white; font-weight: 600;">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container" style="padding: 30px 15px;">
        <div class="admin-container">
            <!-- Sidebar Navigation -->
            <div class="admin-sidebar">
                <ul>
                    <li><a href="dashboard.php">📊 Dashboard</a></li>
                    <li><a href="manage-schemes.php" class="active">📚 Manage Schemes</a></li>
                    <li><a href="eligibility-rules.php">📋 Eligibility Rules</a></li>
                    <li><a href="view-users.php">👥 View Users</a></li>
                    <li><a href="view-applications.php">📑 View Applications</a></li>
                    <li><a href="activity-logs.php">📜 Activity Logs</a></li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="admin-content">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <h2 class="admin-title">📚 Manage Schemes</h2>
                    <a href="add-scheme.php" class="btn btn-primary">+ Add New Scheme</a>
                </div>

                <!-- Schemes Table -->
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Scheme Name</th>
                            <th>Category</th>
                            <th>Status</th>
                            <th>Created Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($scheme = $schemesResult->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($scheme['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($scheme['category']); ?></td>
                            <td>
                                <span style="padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: 600;
                                    background-color: <?php echo $scheme['status'] === 'active' ? '#c8e6c9' : '#ffcdd2'; ?>;
                                    color: <?php echo $scheme['status'] === 'active' ? '#1b5e20' : '#b71c1c'; ?>;">
                                    <?php echo ucfirst($scheme['status']); ?>
                                </span>
                            </td>
                            <td><?php echo !empty($scheme['created_at']) ? date('M d, Y', strtotime($scheme['created_at'])) : 'N/A'; ?></td>
                            <td>
                                <div class="admin-actions">
                                    <a href="edit-scheme.php?id=<?php echo $scheme['id']; ?>" class="btn btn-small btn-secondary">Edit</a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this scheme?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="scheme_id" value="<?php echo $scheme['id']; ?>">
                                        <button type="submit" class="btn btn-small btn-outline" style="color: #d32f2f; border-color: #d32f2f;">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
