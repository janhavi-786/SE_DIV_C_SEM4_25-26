<?php
// Admin Login Handler
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../includes/db_config.php';

$response = ['success' => false, 'message' => '', 'redirect' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Validation
    if (empty($username) || empty($password)) {
        $response['message'] = 'Username and password are required.';
        echo json_encode($response);
        exit();
    }

    // Check admin user
    $result = $conn->query("SELECT * FROM admin_users WHERE username = '$username'");

    if ($result->num_rows === 0) {
        $response['message'] = 'Invalid credentials.';
        logActivity(null, null, "Failed admin login attempt: $username");
        echo json_encode($response);
        exit();
    }

    $admin = $result->fetch_assoc();
    $hashedPassword = hash('sha256', $password);

    if ($admin['password'] !== $hashedPassword) {
        $response['message'] = 'Invalid credentials.';
        logActivity(null, null, "Failed admin login attempt: $username");
        echo json_encode($response);
        exit();
    }

    // Login successful
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['admin_role'] = $admin['role'];

    $response['success'] = true;
    $response['message'] = 'Admin login successful!';
    $response['redirect'] = '/FindMyScheme/admin/dashboard.php';
    
    logActivity(null, null, "Admin logged in: $username");
}

echo json_encode($response);
?>
