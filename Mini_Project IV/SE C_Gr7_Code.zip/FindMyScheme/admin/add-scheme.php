<?php
// Add Scheme Page
session_start();
require_once __DIR__ . '/../includes/auth.php';

if (!isAdminLoggedIn()) {
    header("Location: login.html");
    exit();
}

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $benefits = sanitize($_POST['benefits'] ?? '');
    $category = sanitize($_POST['category'] ?? '');
    $apply_url = sanitize($_POST['apply_url'] ?? '');
    $application_process = sanitize($_POST['application_process'] ?? '');
    $required_documents = sanitize($_POST['required_documents'] ?? '');

    if (empty($name) || empty($description)) {
        $error_message = 'Scheme name and description are required.';
    } else {
        $sql = "INSERT INTO schemes (name, description, benefits, category, apply_url, application_process, required_documents, status) 
                VALUES ('$name', '$description', '$benefits', '$category', '$apply_url', '$application_process', '$required_documents', 'active')";
        
        if ($conn->query($sql)) {
            $success_message = 'Scheme added successfully!';
            $_POST = array();
        } else {
            $error_message = 'Error adding scheme: ' . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Scheme - FindMyScheme Admin</title>
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <!-- Admin Header -->
    <div class="admin-header">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center;">
                    <img src="../assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px;">
                    <h1 style="margin: 0;"><span style="color: #FF9933;">FindMyScheme</span> <span style="color: white;">Admin</span></h1>
                </div>
                <a href="logout.php" style="color: white; font-weight: 600;">Logout</a>
            </div>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container" style="padding: 30px 15px;">
        <div class="admin-container">
            <!-- Sidebar Navigation -->
            <div class="admin-sidebar">
                <ul>
                    <li><a href="dashboard.php">📊 Dashboard</a></li>
                    <li><a href="manage-schemes.php" class="active">📚 Manage Schemes</a></li>
                    <li><a href="eligibility-rules.php">📋 Eligibility Rules</a></li>
                    <li><a href="view-users.php">👥 View Users</a></li>
                    <li><a href="view-applications.php">📑 View Applications</a></li>
                    <li><a href="activity-logs.php">📜 Activity Logs</a></li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="admin-content">
                <h2 class="admin-title">➕ Add New Scheme</h2>

                <?php if ($success_message): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php endif; ?>

                <?php if ($error_message): ?>
                    <div class="alert alert-error"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <form method="POST" style="max-width: 600px;">
                    <div class="form-group">
                        <label for="name">Scheme Name *</label>
                        <input type="text" id="name" name="name" value="<?php echo $_POST['name'] ?? ''; ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="category">Category *</label>
                        <select id="category" name="category" required>
                            <option value="">Select Category</option>
                            <option value="Healthcare">Healthcare</option>
                            <option value="Education">Education</option>
                            <option value="Employment">Employment</option>
                            <option value="Finance">Finance</option>
                            <option value="Social Security">Social Security</option>
                            <option value="Agriculture">Agriculture</option>
                            <option value="Energy">Energy</option>
                            <option value="Infrastructure">Infrastructure</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="description">Description *</label>
                        <textarea id="description" name="description" rows="4" required><?php echo $_POST['description'] ?? ''; ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="benefits">Benefits</label>
                        <textarea id="benefits" name="benefits" rows="4"><?php echo $_POST['benefits'] ?? ''; ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="application_process">Application Process (optional)</label>
                        <textarea id="application_process" name="application_process" rows="4" placeholder="Step-by-step guide on how to apply"><?php echo $_POST['application_process'] ?? ''; ?></textarea>
                        <small style="color:#666;">Describe the step-by-step process for applying to this scheme.</small>
                    </div>

                    <div class="form-group">
                        <label for="apply_url">Apply Link (optional)</label>
                        <input type="url" id="apply_url" name="apply_url" value="<?php echo $_POST['apply_url'] ?? ''; ?>" placeholder="https://...">
                        <small style="color:#666;">If available, users will be redirected to this official portal link.</small>
                    </div>

                    <div class="form-group">
                        <label for="required_documents">Required Documents (optional)</label>
                        <textarea id="required_documents" name="required_documents" rows="5" placeholder="One document per line"><?php echo $_POST['required_documents'] ?? ''; ?></textarea>
                        <small style="color:#666;">Example: Aadhaar Card, Income Certificate, Bank Passbook… (one per line)</small>
                    </div>

                    <div style="display: flex; gap: 10px;">
                        <button type="submit" class="btn btn-primary">Add Scheme</button>
                        <a href="manage-schemes.php" class="btn btn-outline">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
