<?php
// Admin Dashboard
session_start();
require_once __DIR__ . '/../includes/auth.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    header("Location: login.html");
    exit();
}

// Get admin info
$admin = getCurrentAdmin();

// Get statistics
$totalSchemesResult = $conn->query("SELECT COUNT(*) as total FROM schemes");
$totalSchemes = $totalSchemesResult->fetch_assoc()['total'];

$activeSchemesResult = $conn->query("SELECT COUNT(*) as total FROM schemes WHERE status = 'active'");
$activeSchemes = $activeSchemesResult->fetch_assoc()['total'];

$totalUsersResult = $conn->query("SELECT COUNT(*) as total FROM users");
$totalUsers = $totalUsersResult->fetch_assoc()['total'];

$totalApplicationsResult = $conn->query("SELECT COUNT(*) as total FROM user_scheme_applications");
$totalApplications = $totalApplicationsResult->fetch_assoc()['total'];

// Get recent schemes
$recentSchemesResult = $conn->query("SELECT id, name, status, created_at FROM schemes ORDER BY created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - FindMyScheme</title>
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <!-- Admin Header -->
    <div class="admin-header">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center;">
                    <img src="../assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px;">
                    <h1 style="margin: 0;"><span style="color: #FF9933;">FindMyScheme</span> <span style="color: white;">Admin</span></h1>
                </div>
                <div style="display: flex; gap: 20px; align-items: center;">
                    <span>Welcome, <?php echo htmlspecialchars($admin['username']); ?> ✋</span>
                    <a href="logout.php" style="color: white; font-weight: 600;">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Admin Container -->
    <div class="container" style="padding: 30px 15px;">
        <div class="admin-container">
            <!-- Sidebar Navigation -->
            <div class="admin-sidebar">
                <ul>
                    <li><a href="dashboard.php" class="active">📊 Dashboard</a></li>
                    <li><a href="manage-schemes.php">📚 Manage Schemes</a></li>
                    <li><a href="eligibility-rules.php">📋 Eligibility Rules</a></li>
                    <li><a href="view-users.php">👥 View Users</a></li>
                    <li><a href="view-applications.php">📑 View Applications</a></li>
                    <li><a href="activity-logs.php">📜 Activity Logs</a></li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="admin-content">
                <h2 class="admin-title">📊 Dashboard Overview</h2>

                <!-- Statistics Cards -->
                <div class="admin-stats">
                    <div class="stat-card">
                        <div class="stat-number"><?php echo $totalSchemes; ?></div>
                        <div class="stat-label">Total Schemes</div>
                    </div>
                    <div class="stat-card" style="background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%);">
                        <div class="stat-number"><?php echo $activeSchemes; ?></div>
                        <div class="stat-label">Active Schemes</div>
                    </div>
                    <div class="stat-card" style="background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%);">
                        <div class="stat-number"><?php echo $totalUsers; ?></div>
                        <div class="stat-label">Registered Users</div>
                    </div>
                    <div class="stat-card" style="background: linear-gradient(135deg, #1a237e 0%, #0d47a1 100%); cursor: pointer;" onclick="window.location.href='view-applications.php'">
                        <div class="stat-number"><?php echo $totalApplications; ?></div>
                        <div class="stat-label">Total Applications</div>
                    </div>
                </div>

                <!-- Recent Schemes -->
                <h3 style="margin-top: 40px; margin-bottom: 20px;">📚 Recent Schemes</h3>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Scheme Name</th>
                            <th>Status</th>
                            <th>Created Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($scheme = $recentSchemesResult->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($scheme['name']); ?></td>
                            <td>
                                <span style="padding: 5px 10px; border-radius: 20px; font-size: 12px; font-weight: 600;
                                    background-color: <?php echo $scheme['status'] === 'active' ? '#c8e6c9' : '#ffcdd2'; ?>;
                                    color: <?php echo $scheme['status'] === 'active' ? '#1b5e20' : '#b71c1c'; ?>;">
                                    <?php echo ucfirst($scheme['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($scheme['created_at'])); ?></td>
                            <td>
                                <div class="admin-actions">
                                    <a href="edit-scheme.php?id=<?php echo $scheme['id']; ?>" class="btn btn-small btn-secondary">Edit</a>
                                    <a href="delete-scheme.php?id=<?php echo $scheme['id']; ?>" class="btn btn-small btn-outline" style="color: #d32f2f; border-color: #d32f2f;" onclick="return confirm('Are you sure?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <!-- Quick Actions -->
                <div style="margin-top: 40px; display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                    <div class="card" style="border-left-color: #ff9800;">
                        <h4 style="color: #ff9800; margin-bottom: 10px;">➕ Add New Scheme</h4>
                        <p style="font-size: 13px; color: #666; margin-bottom: 15px;">Add a new government scheme to the database.</p>
                        <a href="add-scheme.php" class="btn btn-primary" style="width: 100%; text-align: center;">Add Scheme</a>
                    </div>

                    <div class="card" style="border-left-color: #2e7d32;">
                        <h4 style="color: #2e7d32; margin-bottom: 10px;">⚙️ Manage Eligibility</h4>
                        <p style="font-size: 13px; color: #666; margin-bottom: 15px;">Set and update eligibility rules for schemes.</p>
                        <a href="eligibility-rules.php" class="btn btn-success" style="width: 100%; text-align: center;">Manage Rules</a>
                    </div>

                    <div class="card" style="border-left-color: #1a237e;">
                        <h4 style="color: #1a237e; margin-bottom: 10px;">📊 View Reports</h4>
                        <p style="font-size: 13px; color: #666; margin-bottom: 15px;">Check user activity and application statistics.</p>
                        <a href="activity-logs.php" class="btn btn-secondary" style="width: 100%; text-align: center;">View Reports</a>
                    </div>
                </div>

                <!-- Help Section -->
                <div style="margin-top: 40px; background-color: #fff3cd; padding: 20px; border-radius: 8px; border-left: 4px solid #ff9800;">
                    <h4 style="color: #856404; margin-bottom: 10px;">💡 Admin Tips</h4>
                    <ul style="color: #856404; margin: 0; padding-left: 20px;">
                        <li>Regularly update scheme information to ensure accuracy</li>
                        <li>Review eligibility rules frequently as government guidelines change</li>
                        <li>Monitor user feedback and activity logs for improvements</li>
                        <li>Keep the system updated with new schemes as they are announced</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
