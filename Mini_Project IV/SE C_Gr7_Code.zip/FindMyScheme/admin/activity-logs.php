<?php
// Activity Logs Page
session_start();
require_once __DIR__ . '/../includes/auth.php';

if (!isAdminLoggedIn()) {
    header("Location: login.html");
    exit();
}

// Get activity logs
$logsResult = $conn->query("SELECT id, user_id, action, details, ip_address, created_at FROM activity_logs ORDER BY created_at DESC LIMIT 100");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Logs - FindMyScheme Admin</title>
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <!-- Admin Header -->
    <div class="admin-header">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center;">
                    <img src="../assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px;">
                    <h1 style="margin: 0;"><span style="color: #FF9933;">FindMyScheme</span> <span style="color: white;">Admin</span></h1>
                </div>
                <a href="logout.php" style="color: white; font-weight: 600;">Logout</a>
            </div>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container" style="padding: 30px 15px;">
        <div class="admin-container">
            <!-- Sidebar Navigation -->
            <div class="admin-sidebar">
                <ul>
                    <li><a href="dashboard.php">📊 Dashboard</a></li>
                    <li><a href="manage-schemes.php">📚 Manage Schemes</a></li>
                    <li><a href="eligibility-rules.php">📋 Eligibility Rules</a></li>
                    <li><a href="view-users.php">👥 View Users</a></li>
                    <li><a href="view-applications.php">📑 View Applications</a></li>
                    <li><a href="activity-logs.php" class="active">📜 Activity Logs</a></li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="admin-content">
                <h2 class="admin-title">📜 Activity Logs</h2>

                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>User ID</th>
                            <th>Details</th>
                            <th>IP Address</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($log = $logsResult->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($log['action']); ?></strong></td>
                            <td><?php echo $log['user_id'] ? $log['user_id'] : 'System'; ?></td>
                            <td style="font-size: 12px; color: #666;"><?php echo htmlspecialchars($log['details']); ?></td>
                            <td style="font-size: 12px;"><?php echo htmlspecialchars($log['ip_address']); ?></td>
                            <td><?php echo date('M d, Y H:i', strtotime($log['created_at'])); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
