<?php
// Mode Selection with Session Protection
session_start();
require_once __DIR__ . '/includes/auth.php';

if (!isLoggedIn()) {
    header("Location: /FindMyScheme/login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mode Selection - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="profile.php">Profile</a>
                    <a href="php/logout.php" class="btn btn-primary btn-small">Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Mode Selection Section -->
    <section class="mode-selection">
        <div class="container">
            <h2 style="text-align: center; margin-bottom: 15px;">How Would You Like to Proceed?</h2>
            <p style="text-align: center; color: #666; margin-bottom: 50px; font-size: 16px;">
                Choose the mode that works best for you. Both will help you find your eligible schemes.
            </p>

            <div class="mode-cards">
                <!-- Self Mode Card -->
                <div class="mode-card">
                    <div class="mode-card-icon">🎯</div>
                    <h3>Self Mode</h3>
                    <p>Fill your details independently and explore schemes at your own pace. Perfect for those who prefer to work alone.</p>
                    <a href="user-details.php?mode=self" class="btn btn-primary btn-block">Start Self Mode</a>
                </div>

                <!-- Assisted Mode Card -->
                <div class="mode-card">
                    <div class="mode-card-icon">🤖</div>
                    <h3>Assisted Mode</h3>
                    <p>Get guided step-by-step through the process. Our chatbot will help you at every step with explanations and tips.</p>
                    <a href="user-details.php?mode=assisted" class="btn btn-primary btn-block">Start Assisted Mode</a>
                </div>
            </div>

            <!-- Info Cards -->
            <div style="margin-top: 50px; display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
                <div class="card">
                    <h4 style="color: #ff9800; margin-bottom: 10px;">📋 What You'll Need</h4>
                    <ul style="list-style: none; padding: 0;">
                        <li style="padding: 8px 0; padding-left: 25px; position: relative;">
                            <span style="position: absolute; left: 0; color: #2e7d32;">✓</span>
                            Your age
                        </li>
                        <li style="padding: 8px 0; padding-left: 25px; position: relative;">
                            <span style="position: absolute; left: 0; color: #2e7d32;">✓</span>
                            Annual income
                        </li>
                        <li style="padding: 8px 0; padding-left: 25px; position: relative;">
                            <span style="position: absolute; left: 0; color: #2e7d32;">✓</span>
                            Your state
                        </li>
                        <li style="padding: 8px 0; padding-left: 25px; position: relative;">
                            <span style="position: absolute; left: 0; color: #2e7d32;">✓</span>
                            Caste (optional)
                        </li>
                        <li style="padding: 8px 0; padding-left: 25px; position: relative;">
                            <span style="position: absolute; left: 0; color: #2e7d32;">✓</span>
                            Occupation (optional)
                        </li>
                    </ul>
                </div>

                <div class="card">
                    <h4 style="color: #ff9800; margin-bottom: 10px;">🔒 Privacy & Security</h4>
                    <p style="font-size: 14px;">
                        Your data is completely secure and encrypted. We never share your information with third parties. You can trust us with your personal information.
                    </p>
                </div>

                <div class="card">
                    <h4 style="color: #ff9800; margin-bottom: 10px;">⏱️ Time Required</h4>
                    <p style="font-size: 14px;">
                        <strong>Self Mode:</strong> 5-10 minutes
                    </p>
                    <p style="font-size: 14px; margin-top: 10px;">
                        <strong>Assisted Mode:</strong> 10-15 minutes
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/chatbot.js"></script>
</body>
</html>
