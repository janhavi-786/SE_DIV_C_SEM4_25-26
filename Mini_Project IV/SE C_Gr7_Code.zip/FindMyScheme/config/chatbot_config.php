<?php
/**
 * FindMyScheme — Scheme Guidance Assistant Configuration
 * AI-powered logic for explaining schemes and website usage.
 */

require_once __DIR__ . '/../includes/env_loader.php';

// =============================================
// API CONFIGURATION (Loaded from .env)
// =============================================
define('GOOGLE_API_KEY', getenv('GEMINI_API_KEY'));
define('GEMINI_MODEL', getenv('GEMINI_MODEL') ?: 'gemini-1.5-flash');

// =============================================
// SCHEME DATA (Used for AI Context)
// =============================================
$SCHEME_DATA = [
    'nrega' => [
        'name' => 'NREGA (Mahatma Gandhi National Rural Employment Guarantee Act)',
        'type' => 'employment',
        'purpose' => 'Provides guaranteed employment to rural households to improve livelihood security.',
        'benefits' => [
            '100 days of wage employment per financial year',
            'Government-funded wages',
            'Employment provided within 15 days of application',
            'Improves rural infrastructure'
        ],
        'eligibility' => 'Rural households with adult members willing to do manual work.',
        'documents' => ['Aadhaar card', 'Job card', 'Bank account details'],
        'how_to_apply' => 'Visit your local Gram Panchayat office and register for a job card.'
    ],
    'pm-jay' => [
        'name' => 'PM-JAY (Ayushman Bharat Yojana)',
        'type' => 'health',
        'purpose' => 'World\'s largest health insurance scheme providing free medical coverage.',
        'benefits' => [
            'Coverage of up to ₹5 lakh per family per year',
            'Cashless treatment at public and empanelled private hospitals',
            'Covers pre and post-hospitalization expenses',
            'Includes secondary and tertiary care'
        ],
        'eligibility' => 'Low-income families listed in SECC 2011 data, rural households, and identified urban workers.',
        'documents' => ['Aadhaar card', 'Ration card', 'Mobile number linked with Aadhaar'],
        'how_to_apply' => 'Check eligibility on the PM-JAY portal and visit a Common Service Centre (CSC) for card generation.'
    ],
    'pm-kisan' => [
        'name' => 'PM-Kisan Samman Nidhi',
        'type' => 'finance',
        'purpose' => 'Provides income support to all landholding farmer families in India.',
        'benefits' => [
            '₹6,000 per year in three equal installments',
            'Direct Benefit Transfer (DBT) to bank accounts',
            'Supports small and marginal farmers with agricultural expenses'
        ],
        'eligibility' => 'All landholding farmer families across the country (subject to certain exclusions).',
        'documents' => ['Aadhaar card', 'Land ownership documents', 'Bank account details'],
        'how_to_apply' => 'Register on the PM-Kisan portal or visit a local CSC center.'
    ],
    'scholarship' => [
        'name' => 'Post-Matric Scholarship (OBC/SC/ST)',
        'type' => 'education',
        'purpose' => 'Financial assistance to students belonging to reserved categories for higher education.',
        'benefits' => [
            'Reimbursement of tuition fees',
            'Monthly maintenance allowance',
            'Covers professional and non-professional courses'
        ],
        'eligibility' => 'Students from OBC/SC/ST categories with family income below a certain limit, studying in post-matric courses.',
        'documents' => ['Caste certificate', 'Income certificate', 'Last year mark sheet', 'Aadhaar card'],
        'how_to_apply' => 'Apply through the National Scholarship Portal (NSP) or state-specific scholarship portals.'
    ],
    'sukanya' => [
        'name' => 'Sukanya Samriddhi Yojana',
        'type' => 'education',
        'purpose' => 'Long-term savings scheme for the girl child to support her education and future needs.',
        'benefits' => [
            'Attractive interest rate with annual compounding',
            'Income tax benefits under Section 80C',
            'Account can be opened in the name of a girl child below 10 years',
            'Partial withdrawal allowed for higher education of the girl'
        ],
        'eligibility' => 'Parents or legal guardians of a girl child below 10 years of age can open the account. Only one account per girl child, and up to two girls per family (exceptions for twins).',
        'documents' => [
            'Birth certificate of the girl child',
            'Identity and address proof of parent/guardian (Aadhaar, PAN, etc.)',
            'Passport size photographs',
            'Initial deposit amount'
        ],
        'how_to_apply' => 'Visit a participating bank branch or post office, fill the Sukanya Samriddhi account form, attach the girl\'s birth certificate and KYC documents of the parent/guardian, and make the initial deposit.'
    ]
];

// =============================================
// WEBSITE GUIDANCE DATA
// =============================================
$WEBSITE_GUIDANCE = [
    'register' => [
        'keywords' => ['how to register', 'register', 'create account', 'sign up', 'signup'],
        'response' => "**How to Register (Create Account)**\n\nStep 1 → Open the Register page\nStep 2 → Enter your name, email, and password\nStep 3 → Click **Create Account**\nStep 4 → Go to Login and sign in\n\nTip: Use a strong password (uppercase + lowercase + number)."
    ],
    'login' => [
        'keywords' => ['how to login', 'login', 'sign in', 'signin'],
        'response' => "**How to Login**\n\nStep 1 → Open the Login page\nStep 2 → Enter your email and password\nStep 3 → Click **Login**\nStep 4 → You will reach your Dashboard"
    ],
    'assisted_mode' => [
        'keywords' => ['assisted mode', 'what is assisted', 'how to use assisted'],
        'response' => "**Assisted Mode** is a special feature on our website that guides you step-by-step through a simple questionnaire. It helps you find eligible schemes without you having to search for them yourself. You can find it on your Dashboard under 'Find My Scheme'."
    ],
    'complete_profile' => [
        'keywords' => ['complete profile', 'update profile', 'profile help', 'change my details'],
        'response' => "To **complete your profile**, click on the 'Profile' link in the top menu. Make sure to enter your correct age, income, and state. This information is used by the system to match you with eligible schemes."
    ],
    'how_to_apply_site' => [
        'keywords' => ['how to apply', 'apply for scheme', 'application process', 'how do i apply', 'apply now'],
        'response' => "**How to Apply for a Scheme (on FindMyScheme)**\n\nStep 1 → Login to your account\nStep 2 → Dashboard → Click **Find My Schemes**\nStep 3 → Fill your details (age, income, state, etc.)\nStep 4 → View eligible schemes on Results page\nStep 5 → Click **Learn More** → read documents + process\nStep 6 → Click **Apply Now** to open the official government portal\n\nNote: Final application is done on the official portal."
    ],
    'upload_documents_site' => [
        'keywords' => ['upload document', 'upload docs', 'how to upload'],
        'response' => "On **FindMyScheme**, you don't need to upload documents to find schemes. However, when you apply on the official government portal, you will need scanned copies of your Aadhaar, Income certificate, etc. Keep them ready in PDF or JPG format."
    ],
    'check_status' => [
        'keywords' => ['check status', 'track application', 'application status'],
        'response' => "To **check your application status**, you must visit the official portal where you applied. Use your Application ID or Reference Number provided during submission. We do not track government application progress directly."
    ]
];

// =============================================
// DOCUMENT GUIDANCE
// =============================================
$DOCUMENT_GUIDANCE = [
    'aadhaar' => "The **Aadhaar Card** is the most important identity document. It is used to verify your identity and link your bank account for Direct Benefit Transfers (DBT).",
    'income'  => "An **Income Certificate** proves your family's annual earnings. Many schemes have an income limit (e.g., below ₹2.5 lakh) to ensure help reaches those who need it most.",
    'caste'   => "A **Caste Certificate** is required for schemes reserved for SC, ST, or OBC categories. It must be issued by a competent authority in your state.",
    'bank'    => "**Bank Account Details** (Account number and IFSC code) are essential for receiving money directly from the government."
];

// =============================================
// PRIORITY LOGIC SETTINGS
// =============================================
$PRIORITY_LEVELS = [
    'health'    => 1, // Highest
    'education' => 2, // Medium
    'finance'   => 3, // Lower
    'employment'=> 3,
    'other'     => 4
];

$PRIORITY_REASONS = [
    'health'    => "Health insurance protects you from sudden medical expenses which can be an emergency for any family.",
    'education' => "Education funding is important for future growth but is usually less urgent than a medical emergency.",
    'finance'   => "Financial support provides stability but can be applied for after securing health and education needs."
];

// =============================================
// CHATBOT GREETING
// =============================================
$GREETING_MESSAGE = "Hello! I am your **Scheme Guidance Assistant**.\n\nYou can ask me things like:\n• Tell me about NREGA\n• Which scheme should I apply first?\n• What documents are required for schemes?\n• What is Assisted Mode?";
$GREETING_MESSAGE = "Hello! I am your **FindMyScheme Guidance Assistant**.";

$FALLBACK_MESSAGE = "I'm not sure I understand that. I can help you with scheme explanations, priority recommendations, or website guidance. Try asking \"Tell me about PM-JAY\" or \"What is Assisted Mode?\"";
?>