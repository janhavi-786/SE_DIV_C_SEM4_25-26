<?php
// Search History Page
session_start();
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db_config.php';

if (!isLoggedIn()) {
    header("Location: /FindMyScheme/login.php");
    exit();
}

$userId = (int) $_SESSION['user_id'];

// Get search history sessions
$historySql = "SELECT * FROM search_history WHERE user_id = $userId ORDER BY created_at DESC";
$historyResult = $conn->query($historySql);

// Function to format JSON params
function formatParams($json) {
    $params = json_decode($json, true);
    if (!$params) return "No details provided";
    
    $parts = [];
    if (!empty($params['age'])) $parts[] = "Age: {$params['age']}";
    if (!empty($params['income'])) $parts[] = "Income: ₹" . number_format($params['income']);
    if (!empty($params['state'])) $parts[] = "State: {$params['state']}";
    if (!empty($params['occupation'])) $parts[] = "Job: {$params['occupation']}";
    
    return implode(' | ', $parts);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search History - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
    <style>
        .history-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            border-left: 5px solid #1a237e;
            transition: transform 0.2s;
        }
        .history-card:hover {
            transform: translateY(-2px);
        }
        .history-date {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .history-params {
            background: #f8f9fa;
            padding: 10px 15px;
            border-radius: 6px;
            font-size: 0.95rem;
            margin: 15px 0;
            color: #444;
        }
        .history-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
        }
        .results-badge {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        .empty-history {
            text-align: center;
            padding: 60px 20px;
            background: #f9f9f9;
            border-radius: 12px;
            border: 2px dashed #ddd;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="profile.php">Profile</a>
                    <a href="php/logout.php" class="btn btn-primary btn-small">Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <div class="container" style="padding: 40px 15px;">
        <div style="margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h1 style="color: #1a237e;">📜 Search History</h1>
                <p style="color: #666;">View your previous scheme recommendations</p>
            </div>
            <a href="mode-selection.php" class="btn btn-primary">New Search</a>
        </div>

        <?php if ($historyResult->num_rows > 0): ?>
            <?php while($row = $historyResult->fetch_assoc()): ?>
                <div class="history-card">
                    <div class="history-date">
                        📅 <?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?>
                    </div>
                    
                    <div class="history-params">
                        <strong>Search Details:</strong><br>
                        <?php echo htmlspecialchars(formatParams($row['search_params'])); ?>
                    </div>

                    <div class="history-footer">
                        <span class="results-badge">
                            ✨ <?php echo $row['results_count']; ?> Schemes Found
                        </span>
                        
                        <div>
                            <a href="view-results.php?search_id=<?php echo $row['id']; ?>" class="btn btn-success btn-small">View Results</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="empty-history">
                <div style="font-size: 3rem; margin-bottom: 20px;">🏜️</div>
                <h3>No History Found</h3>
                <p style="color: #666; margin-bottom: 25px;">You haven't searched for any schemes yet. Start your first search now!</p>
                <a href="mode-selection.php" class="btn btn-primary">Find My Schemes</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/chatbot.js"></script>
</body>
</html>
