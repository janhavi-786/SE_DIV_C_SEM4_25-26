<?php
// Login Page (session-aware)
session_start();
require_once __DIR__ . '/includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header("Location: /FindMyScheme/dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="register.php" class="btn btn-outline btn-small" style="border-color: white; color: white;">Register</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Login Container -->
    <div class="auth-container">
        <div class="auth-header">
            <div class="auth-logo">🔐</div>
            <h2 class="auth-title">Login to Your Account</h2>
        </div>

        <form id="loginForm" onsubmit="return false;">
            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
                <div class="form-error" id="emailError"></div>
            </div>

            <div class="form-group">
                <label for="password">Password *</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
                <div class="form-error" id="passwordError"></div>
            </div>

            <div id="errorMessage" class="alert alert-error" style="display: none; margin-bottom: 15px;"></div>

            <button type="submit" class="btn btn-primary btn-block" style="margin-top: 20px; padding: 12px;">Login</button>
        </form>

        <div class="auth-footer">
            <p>Don't have an account? <a href="register.php">Register here</a></p>
            <p style="font-size: 12px; margin-top: 10px;">
                <a href="admin/login.php" style="color: var(--saffron);">Admin Login</a>
            </p>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/validation.js"></script>
    <script src="js/login.js"></script>
    <script src="js/chatbot.js"></script>
</body>
</html>
