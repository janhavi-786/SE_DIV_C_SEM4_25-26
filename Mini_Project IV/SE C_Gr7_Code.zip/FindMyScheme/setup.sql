-- Create FindMyScheme Database
CREATE DATABASE IF NOT EXISTS findmyscheme;
USE findmyscheme;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    age INT,
    income DECIMAL(15, 2),
    caste VARCHAR(50),
    state VARCHAR(50),
    occupation VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Admin Users Table
CREATE TABLE IF NOT EXISTS admin_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'admin',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Schemes Table
CREATE TABLE IF NOT EXISTS schemes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    benefits TEXT,
    category VARCHAR(100),
    apply_url VARCHAR(255),
    application_process TEXT,
    required_documents TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Eligibility Rules Table
CREATE TABLE IF NOT EXISTS eligibility_rules (
    id INT PRIMARY KEY AUTO_INCREMENT,
    scheme_id INT NOT NULL,
    age_min INT,
    age_max INT,
    income_max DECIMAL(15, 2),
    caste_category VARCHAR(50),
    states JSON,
    occupations JSON,
    other_criteria TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (scheme_id) REFERENCES schemes(id) ON DELETE CASCADE
);

-- User Scheme Applications Table
CREATE TABLE IF NOT EXISTS user_scheme_applications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    scheme_id INT NOT NULL,
    search_id INT NULL,
    confidence_level ENUM('low', 'medium', 'high') DEFAULT 'medium',
    eligibility_details JSON,
    application_status ENUM('eligible', 'ineligible', 'partial') DEFAULT 'eligible',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (scheme_id) REFERENCES schemes(id) ON DELETE CASCADE
);

-- Search History Table
CREATE TABLE IF NOT EXISTS search_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    search_params JSON,
    results_count INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Chatbot Logs Table
CREATE TABLE IF NOT EXISTS chatbot_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    message TEXT NOT NULL,
    response TEXT NOT NULL,
    intent VARCHAR(100),
    confidence DECIMAL(5, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Activity Logs Table
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(200) NOT NULL,
    details TEXT,
    ip_address VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Insert Sample Admin
INSERT INTO admin_users (username, email, password, role) 
VALUES ('admin', 'admin@findmyscheme.gov', SHA2('admin123', 256), 'admin')
ON DUPLICATE KEY UPDATE password = SHA2('admin123', 256);

-- Insert Sample Schemes
INSERT INTO schemes (name, description, benefits, category, status) VALUES
('PM-JAY: Ayushman Bharat', 'Health insurance scheme for poor families', 'Free health coverage up to ₹5 lakhs', 'Healthcare', 'active'),
('Sukanya Samriddhi Yojana', 'Savings scheme for girl child', 'Tax benefits and high interest rates', 'Education', 'active'),
('Pradhan Mantri Ujjwala Yojana', 'LPG connection for poor families', 'Free LPG cylinder connection', 'Energy', 'active'),
('NREGA', 'Rural employment guarantee scheme', '100 days employment guarantee', 'Employment', 'active'),
('Scholarship for OBC', 'Educational scholarship for OBC candidates', 'Full tuition fee coverage', 'Education', 'active'),
('Old Age Pension', 'Monthly pension for elderly citizens', 'Monetary support for senior citizens', 'Social Security', 'active')
ON DUPLICATE KEY UPDATE status = 'active';

-- Insert Eligibility Rules (Sample Data)
INSERT INTO eligibility_rules (scheme_id, age_min, age_max, income_max, caste_category, other_criteria) VALUES
(1, 0, 120, 500000, NULL, 'BPL families'),
(2, 0, 25, NULL, NULL, 'Girl child only'),
(3, 0, 120, 100000, NULL, 'Rural areas'),
(4, 18, 65, NULL, NULL, 'Rural residents'),
(5, 0, 30, NULL, 'OBC', 'Class I and II students'),
(6, 60, 120, NULL, NULL, 'No age limit')
ON DUPLICATE KEY UPDATE income_max = income_max;

-- Create indexes for better performance
CREATE INDEX idx_email ON users(email);
CREATE INDEX idx_scheme_status ON schemes(status);
CREATE INDEX idx_user_scheme ON user_scheme_applications(user_id, scheme_id);
CREATE INDEX idx_user_created ON users(created_at);
CREATE INDEX idx_activity_created ON activity_logs(created_at);
