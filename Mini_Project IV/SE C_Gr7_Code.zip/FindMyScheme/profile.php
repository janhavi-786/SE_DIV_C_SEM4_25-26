<?php
// User Profile (view + edit)
session_start();
require_once __DIR__ . '/includes/auth.php';

if (!isLoggedIn()) {
    header("Location: /FindMyScheme/login.html");
    exit();
}

$user = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="php/logout.php" class="btn btn-primary btn-small">Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <div class="form-container">
        <h2 style="text-align: center; margin-bottom: 10px;">My Profile</h2>
        <p style="text-align: center; color: #666; margin-bottom: 30px;">
            View and update your details. This helps us recommend schemes accurately.
        </p>

        <div class="card" style="margin-bottom: 25px; border-left-color: #1a237e;">
            <div style="padding: 18px;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div><strong>Name:</strong> <?php echo htmlspecialchars($user['name'] ?? ''); ?></div>
                    <div><strong>Email:</strong> <?php echo htmlspecialchars($user['email'] ?? ''); ?></div>
                </div>
            </div>
        </div>

        <form id="profileForm">
            <div class="form-section">
                <h3>👤 Personal Details</h3>

                <div class="form-group">
                    <label for="name">Full Name *</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" required>
                    <div class="form-error" id="nameError"></div>
                </div>

                <div class="form-group">
                    <label>Email (cannot be changed)</label>
                    <input type="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" disabled>
                </div>
            </div>

            <div class="form-section">
                <h3>📋 Eligibility Details</h3>

                <div class="form-group">
                    <label for="age">Age</label>
                    <input type="number" id="age" name="age" min="1" max="120" value="<?php echo htmlspecialchars($user['age'] ?? ''); ?>">
                    <div class="form-error" id="ageError"></div>
                </div>

                <div class="form-group">
                    <label for="income">Annual Income (₹)</label>
                    <input type="number" id="income" name="income" min="0" step="1000" value="<?php echo htmlspecialchars($user['income'] ?? ''); ?>">
                    <div class="form-error" id="incomeError"></div>
                </div>

                <div class="form-group">
                    <label for="state">State</label>
                    <select id="state" name="state">
                        <option value="">Select your state</option>
                        <?php
                        $states = [
                            "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
                            "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand",
                            "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur",
                            "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan",
                            "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh",
                            "Uttarakhand", "West Bengal"
                        ];
                        foreach ($states as $state) {
                            $selected = (($user['state'] ?? '') === $state) ? 'selected' : '';
                            echo "<option value=\"$state\" $selected>$state</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="caste">Caste Category</label>
                    <select id="caste" name="caste">
                        <option value="">Select category</option>
                        <?php
                        $castes = ["General", "OBC", "SC", "ST"];
                        foreach ($castes as $caste) {
                            $selected = (($user['caste'] ?? '') === $caste) ? 'selected' : '';
                            echo "<option value=\"$caste\" $selected>$caste</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="occupation">Occupation</label>
                    <select id="occupation" name="occupation">
                        <option value="">Select occupation</option>
                        <?php
                        $occupations = ["Farmer", "Student", "Unemployed", "Self-employed", "Salaried", "Retired", "Housewife", "Other"];
                        foreach ($occupations as $occ) {
                            $selected = (($user['occupation'] ?? '') === $occ) ? 'selected' : '';
                            echo "<option value=\"$occ\" $selected>$occ</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div id="errorMessage" class="alert alert-error" style="display: none; margin-top: 20px;"></div>
            <div id="successMessage" class="alert alert-success" style="display: none; margin-top: 20px;"></div>

            <div class="form-buttons">
                <a href="dashboard.php" class="btn btn-outline">Back</a>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>

    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/validation.js"></script>
    <script src="js/profile.js"></script>
    <script src="js/chatbot.js"></script>
</body>
</html>

