<?php
// Results Page with Session Protection
session_start();
require_once __DIR__ . '/includes/auth.php';

if (!isLoggedIn()) {
    header("Location: /FindMyScheme/login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Schemes - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="dashboard.php">Dashboard</a>
                    <a href="profile.php">Profile</a>
                    <a href="php/logout.php" class="btn btn-primary btn-small">Logout</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Results Section -->
    <section class="results-container">
        <div class="container">
            <div class="results-header">
                <h2>Your Eligible Schemes</h2>
                <p style="color: #666;">Based on your profile, here are the government schemes you qualify for</p>
            </div>

            <!-- Filter Options -->
            <div class="results-filters">
                <button class="btn btn-small btn-secondary" onclick="filterSchemes('all')" data-filter="all">All Schemes</button>
                <button class="btn btn-small btn-outline" onclick="filterSchemes('high')" data-filter="high">High Confidence</button>
                <button class="btn btn-small btn-outline" onclick="filterSchemes('medium')" data-filter="medium">Medium Confidence</button>
                <button class="btn btn-small btn-outline" onclick="filterSchemes('low')" data-filter="low">Low Confidence</button>
            </div>

            <!-- Loading Spinner -->
            <div id="loadingSpinner" style="text-align: center; padding: 40px;">
                <p>⏳ Loading schemes...</p>
            </div>

            <!-- Results Container -->
            <div id="schemesContainer" style="display: none;"></div>

            <!-- No Results Message -->
            <div id="noResults" class="no-results" style="display: none;">
                <h3>No Schemes Found</h3>
                <p>Based on your current profile, we couldn't find any matching schemes. This might change as new schemes are added. Come back later to check again!</p>
                <a href="user-details.php" class="btn btn-primary" style="margin-top: 15px;">Update Your Profile</a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/results.js"></script>
    <script src="js/chatbot.js"></script>
</body>
</html>
