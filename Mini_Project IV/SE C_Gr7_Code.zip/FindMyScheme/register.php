<?php
// Registration Page (session-aware)
session_start();
require_once __DIR__ . '/includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header("Location: /FindMyScheme/dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - FindMyScheme</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <img src="assets/logo.png" alt="FindMyScheme Logo" style="height: 50px; margin-right: 15px; vertical-align: middle;">
                    FindMyScheme
                    <div class="logo-subtitle">Government Schemes at Your Fingertips</div>
                </div>
                <nav>
                    <a href="index.php">Home</a>
                    <a href="login.php" class="btn btn-primary btn-small">Login</a>
                </nav>
            </div>
        </div>
    </header>

    <!-- Registration Container -->
    <div class="auth-container">
        <div class="auth-header">
            <div class="auth-logo">📋</div>
            <h2 class="auth-title">Create Your Account</h2>
        </div>

        <form id="registerForm" onsubmit="return false;">
            <div class="form-group">
                <label for="name">Full Name *</label>
                <input type="text" id="name" name="name" placeholder="Enter your full name" required>
                <div class="form-error" id="nameError"></div>
            </div>

            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
                <div class="form-error" id="emailError"></div>
            </div>

            <div class="form-group">
                <label for="password">Password *</label>
                <input type="password" id="password" name="password" placeholder="Create a strong password" required>
                <div class="form-error" id="passwordError"></div>
                <small style="color: #666; margin-top: 5px;">Minimum 6 characters, include uppercase, lowercase, and numbers</small>
            </div>

            <div class="form-group">
                <label for="confirmPassword">Confirm Password *</label>
                <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm your password" required>
                <div class="form-error" id="confirmError"></div>
            </div>

            <div class="form-group">
                <label for="age">Age</label>
                <input type="number" id="age" name="age" placeholder="Your age" min="1" max="120">
            </div>

            <div class="form-group">
                <label for="state">State</label>
                <select id="state" name="state">
                    <option value="">Select your state</option>
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                    <option value="Assam">Assam</option>
                    <option value="Bihar">Bihar</option>
                    <option value="Chhattisgarh">Chhattisgarh</option>
                    <option value="Delhi">Delhi</option>
                    <option value="Goa">Goa</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Haryana">Haryana</option>
                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                    <option value="Jharkhand">Jharkhand</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Manipur">Manipur</option>
                    <option value="Meghalaya">Meghalaya</option>
                    <option value="Mizoram">Mizoram</option>
                    <option value="Nagaland">Nagaland</option>
                    <option value="Odisha">Odisha</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Rajasthan">Rajasthan</option>
                    <option value="Sikkim">Sikkim</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Telangana">Telangana</option>
                    <option value="Tripura">Tripura</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                    <option value="Uttarakhand">Uttarakhand</option>
                    <option value="West Bengal">West Bengal</option>
                </select>
            </div>

            <div id="successMessage" class="alert alert-success" style="display: none; margin-bottom: 15px;">
                Registration successful! Redirecting to login...
            </div>

            <div id="errorMessage" class="alert alert-error" style="display: none; margin-bottom: 15px;"></div>

            <button type="submit" class="btn btn-primary btn-block" style="margin-top: 20px; padding: 12px;">Create Account</button>
        </form>

        <div class="auth-footer">
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </div>
    </div>

    <!-- Footer -->
    <footer style="background-color: #1a237e; color: white; padding: 30px 15px; text-align: center; margin-top: 60px;">
        <div class="container">
            <p>&copy; 2026 FindMyScheme. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/validation.js"></script>
    <script src="js/register.js"></script>
    <script src="js/chatbot.js"></script>
</body>
</html>
