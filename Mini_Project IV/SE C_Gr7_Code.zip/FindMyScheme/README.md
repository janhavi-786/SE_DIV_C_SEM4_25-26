# 🇮🇳 Smart Government Scheme Finder

**Empowering Indian citizens to discover and access government welfare schemes with ease.**

The **Smart Government Scheme Finder** is a modern web application designed to bridge the awareness gap between the Indian government and its citizens. By providing a personalized, AI-guided experience, it helps users find schemes they are eligible for in seconds instead of hours of manual searching.

---

## 🚀 Key Features

- **Personalized Recommendations**: Intelligent matching between user profiles (age, income, location, etc.) and hundreds of government schemes.
- **AI Guidance Assistant (SAHAYAK)**: A conversational AI chatbot that explains schemes, resolves confusion, and prioritizes applications based on urgency (Health > Education > Finance).
- **Dual Mode Experience**: 
  - **Self Mode**: Quick, standard form-based eligibility check.
  - **Assisted Mode**: Guided step-by-step assistant for non-technical users.
- **Search History**: Track previous scheme searches and eligibility results.
- **Admin Dashboard**: Comprehensive management interface for government officials to maintain scheme data and monitor system activity.
- **Responsive Design**: Works seamlessly on desktops, tablets, and mobile phones.

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3 (Modern Vanilla CSS), JavaScript (Vanilla JS).
- **Backend**: PHP (7.4+).
- **Database**: MySQL.
- **AI Integration**: Google Gemini AI (via API).
- **Others**: `.env` for secure configuration, Python (for optional automation/scraping).

---

## 📁 Project Structure

```text
├── admin/               # Administrative panel and management tools
├── assets/              # Static assets (logos, images)
├── automation/          # Python-based scheme scrapers (optional)
├── config/              # Configuration files (API keys, settings)
├── css/                 # Modern styling system
├── doc/                 # Detailed project documentation
├── includes/            # Core logic, auth, and DB helpers
├── js/                  # Frontend interactivity and API integration
├── php/                 # Backend API endpoints
├── index.php            # Homepage
├── dashboard.php        # User dashboard
└── setup.sql            # Database schema and initial data
```

---

## ⚙️ Setup & Installation

### Prerequisites
- XAMPP / WAMP / LAMP environment.
- PHP 7.4 or higher.
- MySQL database.

### Installation Steps
1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/FindMyScheme.git
   cd FindMyScheme
   ```

2. **Database Setup**:
   - Open phpMyAdmin.
   - Create a new database named `findmyscheme`.
   - Import the `setup.sql` file into the database.

3. **Configuration**:
   - Copy the `.env.example` (if provided) or create a `.env` file in the root.
   - Add your database credentials and **Google Gemini API Key**:
     ```env
     DB_HOST=localhost
     DB_USER=root
     DB_PASS=
     DB_NAME=findmyscheme
     GOOGLE_API_KEY=your_gemini_api_key_here
     ```

4. **Run**:
   - Place the folder in your `htdocs` or equivalent directory.
   - Access the website at `http://localhost/FindMyScheme`.

---

## 🔒 Security
The project implements fundamental security measures:
- **Prepared Statements**: Protection against SQL injection.
- **Password Hashing**: Secure storage of user credentials.
- **Input Sanitization**: Guarding against XSS attacks.
- **Environment Variables**: Sensitive keys are kept outside the codebase.

---

## 📝 License
This project is licensed under the MIT License - see the LICENSE file for details.

---

## 🤝 Contributing
Contributions are welcome! Please feel free to submit a Pull Request.
