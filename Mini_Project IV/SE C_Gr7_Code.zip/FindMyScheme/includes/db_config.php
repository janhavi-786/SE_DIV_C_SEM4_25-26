<?php
// Database Configuration
require_once __DIR__ . '/env_loader.php';

define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_NAME', getenv('DB_NAME') ?: 'findmyscheme');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to UTF-8
$conn->set_charset("utf8mb4");

// Function to sanitize input
function sanitize($input) {
    global $conn;
    return $conn->real_escape_string(htmlspecialchars(strip_tags(trim($input))));
}

// Auto-migration for Search History
$conn->query("CREATE TABLE IF NOT EXISTS search_history (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    search_params JSON,
    results_count INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)");

$checkCol = $conn->query("SHOW COLUMNS FROM user_scheme_applications LIKE 'search_id'");
if ($checkCol && $checkCol->num_rows == 0) {
    $conn->query("ALTER TABLE user_scheme_applications ADD COLUMN search_id INT");
    $conn->query("ALTER TABLE user_scheme_applications ADD FOREIGN KEY (search_id) REFERENCES search_history(id) ON DELETE CASCADE");
}

// Function to log activity
function logActivity($action, $user_id = null, $details = '') {
    global $conn;
    $user_id = $user_id ? $user_id : 'NULL';
    $details = sanitize($details);
    $ip = $_SERVER['REMOTE_ADDR'];
    $query = "INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES ($user_id, '$action', '$details', '$ip')";
    $conn->query($query);
}
?>
