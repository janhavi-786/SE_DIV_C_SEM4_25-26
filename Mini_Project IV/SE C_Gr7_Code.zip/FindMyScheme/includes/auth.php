<?php
// PHP Backend - Authentication & Session Management

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../includes/db_config.php';

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Check if admin is logged in
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

// Get current user
function getCurrentUser() {
    global $conn;
    if (!isLoggedIn()) {
        return null;
    }
    
    $user_id = (int) $_SESSION['user_id'];
    $result = $conn->query("SELECT * FROM users WHERE id = $user_id");
    return $result->fetch_assoc();
}

// Get current admin
function getCurrentAdmin() {
    global $conn;
    if (!isAdminLoggedIn()) {
        return null;
    }
    
    $admin_id = (int) $_SESSION['admin_id'];
    $result = $conn->query("SELECT * FROM admin_users WHERE id = $admin_id");
    return $result->fetch_assoc();
}

// Require login
function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: /FindMyScheme/login.php");
        exit();
    }
}

// Require admin login
function requireAdminLogin() {
    if (!isAdminLoggedIn()) {
        header("Location: /FindMyScheme/admin/login.php");
        exit();
    }
}

// Hash password
function hashPassword($password) {
    return hash('sha256', $password);
}

// Verify password
function verifyPassword($password, $hash) {
    return hash('sha256', $password) === $hash;
}
?>
